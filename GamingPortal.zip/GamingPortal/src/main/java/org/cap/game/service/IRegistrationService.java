package org.cap.game.service;

import org.cap.game.exception.InvalidAgeException;
import org.cap.game.model.Registration;

public interface IRegistrationService {
	
	public void createRegistration(Registration registration) throws InvalidAgeException;
	public Registration getRegistrationDetails();

}
