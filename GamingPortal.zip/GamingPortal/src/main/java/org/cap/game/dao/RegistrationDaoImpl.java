package org.cap.game.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;

import org.cap.game.model.Registration;

public class RegistrationDaoImpl implements IRegistrationDao {

	final static Logger logger=Logger.getLogger(RegistrationDaoImpl.class);
	
	@Override
	public Registration createRegistration(Registration registration) {
		// TODO Auto-generated method stub
		
		String sql="insert into registration values(?,?,?,?,?,?,?);";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1, registration.getRegistrationId());
			statement.setString(2, registration.getCustomerName());
			statement.setString(3, registration.getMobileNo());
			statement.setDouble(4, registration.getRegistrationFees());
			statement.setInt(5, registration.getAge());
			statement.setDouble(6, registration.getActualRegistrationFeesPaid()-registration.getRegistrationFees());
			statement.setDouble(7, registration.getActualRegistrationFeesPaid());
			
			
			
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" row inserted successfully in Registration table!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL Exception while inserting in DB!");
			e.printStackTrace();
		}
		return registration;
		
	}
	

	public Registration getRegistrationDetails() {
		// TODO Auto-generated method stub
		Registration registration=new Registration();
		String str="select * from registration where registrationId=(select max(registrationId) from registration);";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			while(resultSet.next())
			{
				registration.setRegistrationId(resultSet.getInt(1));
				registration.setCustomerName(resultSet.getString(2));
				registration.setActualRegistrationFeesPaid(resultSet.getDouble(7));
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL Exception while getting info from DB!");
			e.printStackTrace();
		}
		return registration;
	}



	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			logger.error("Connection Error!");
			e.printStackTrace();
		}
		return null;
	}
	
}
