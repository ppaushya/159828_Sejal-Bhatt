package org.cap.game.dao;

import org.cap.game.model.Registration;

public interface IRegistrationDao {
	
	public Registration createRegistration(Registration registration);
	public Registration getRegistrationDetails();

}
