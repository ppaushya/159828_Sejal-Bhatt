package org.xyz.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xyz.dao.IAccountDao;
import org.xyz.dao.ITransactionDao;
import org.xyz.model.Account;
import org.xyz.model.Transaction;
import org.xyz.model.TransactionType;

@Service("accountService")
public class AccountService implements IAccountService{

	@Autowired
	IAccountDao accountDao;
	
	@Override
	public boolean addAccount(Account account) {
		accountDao.save(account);
		return true;
	}

	@Override
	public List<Account> getAllAccounts() {
		return accountDao.findAll();
	}

	@Override
	public List<Account> getAccountByCustomerCustomerId(Long customerId) {
		return accountDao.getAccountByCustomerCustomerId(customerId);
	}

	@Override
	public List<Account> getAccountsOfOtherCustomers(long excludedCustomerId) {
		return accountDao.getAccountNotByCustomerCustomerId(excludedCustomerId);
	}

	@Override
	public Account getAccountFromAccountNumber(long accountId) {
		 Optional<Account> optional = accountDao.findById(accountId);
		 if(optional.isPresent()) {
			 return optional.get();
		 }else {
			 return null;
		 }
	}

	@Override
	public double getCurrentBalanceOfAccount(Account account) {
		/*ITransactionDao transactionDao = new TransactionDaoImpl();
		Set<Transaction> transactions = transactionDao.getAllTransactionsOfAccount(account.getAccountNumber());
		double balance = account.getOpeningBalance();
		for(Transaction transaction:transactions) {
			if(transaction.getTransactionType()==TransactionType.DEPOSITE) {
				balance += transaction.getAmount();
			}else if(transaction.getTransactionType()==TransactionType.WITHDRAWAL){
				balance -= transaction.getAmount();
			}else if(transaction.getTransactionType()==TransactionType.FUND_TRANSFER){
				if(transaction.getFromAccount().getAccountNumber() == account.getAccountNumber()) {
					balance -= transaction.getAmount();
				}
				if(transaction.getToAccount().getAccountNumber() == account.getAccountNumber()){
					balance += transaction.getAmount();
				}
			}
		}
		return balance;*/
		return 5000;
	}
}
