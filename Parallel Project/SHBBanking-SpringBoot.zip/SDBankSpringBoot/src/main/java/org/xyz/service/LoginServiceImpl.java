package org.xyz.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xyz.dao.ILoginDao;
import org.xyz.model.CustomerBean;

@Service("loginService")
public class LoginServiceImpl implements ILoginService{

	@Autowired
	private ILoginDao loginDao;

	@Override
	public CustomerBean isValidLogin(CustomerBean customerBean) {
		String email = customerBean.getEmailId();
		String password = customerBean.getPassword();
		System.out.println("email "+email);
		System.out.println("password " + password);
		CustomerBean customerBean2 = getCustomerByEmailIdAndPassword(email,password);
		System.out.println("customerBean2");
		System.out.println(customerBean2);
		return customerBean2;
	}

	@Override
	public CustomerBean getCustomerByEmailIdAndPassword(String email, String password) {
		return loginDao.getCustomerByEmailIdAndPassword(email,password);
	}

	
	
}
