package org.xyz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SDBankSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SDBankSpringBootApplication.class, args);
	}
}
