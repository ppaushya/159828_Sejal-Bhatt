package org.xyz.service;

import java.util.List;
import java.util.Set;

import org.xyz.model.Account;

public interface IAccountService {

	public boolean addAccount(Account account);
	public List<Account> getAllAccounts();
	public List<Account> getAccountByCustomerCustomerId(Long customerId);
	public List<Account> getAccountsOfOtherCustomers(long excludedCustomerId);

	public Account getAccountFromAccountNumber(long accountNumber);
	public double getCurrentBalanceOfAccount(Account account);
}
