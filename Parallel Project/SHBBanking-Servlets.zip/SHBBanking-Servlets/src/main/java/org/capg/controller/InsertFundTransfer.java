package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Transaction;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;
import org.capg.service.ILoginService;
import org.capg.service.ITransactionService;
import org.capg.service.LoginServiceImpl;
import org.capg.service.TransactionServiceImpl;

//this servlet is for insertion of fund transfer data in DB
@WebServlet("/InsertFundTransfer")
public class InsertFundTransfer extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	
		ILoginService loginService=new LoginServiceImpl();
		ITransactionService transactionService=new TransactionServiceImpl();

		//getting data entered by user in HTML form
			String fromAccounts=request.getParameter("fromAccounts");
			String[] fromAccNo=fromAccounts.split(" -");
			long fromAccNumber=Long.parseLong(fromAccNo[0]);
			
			String toAccounts=request.getParameter("toAccounts");
			String[] toAccNo=toAccounts.split(" -");
			long toAccNumber=Long.parseLong(toAccNo[0]);
			
			String fundDescription=request.getParameter("fundDescription");
			double fundAmount=Double.parseDouble(request.getParameter("fundAmount"));
			
			Transaction transaction=new Transaction();
			Transaction tr=new Transaction();
			
			HttpSession session=request.getSession();
			int custId=Integer.parseInt(session.getAttribute("custId").toString());
			PrintWriter out=response.getWriter();
			
			//calculating available balance for amount validation
			Map<Account,Double> currentBalanceDetails=transactionService.getCurrentBalance(custId);
			Set<Account> accounts1=currentBalanceDetails.keySet();
			double currentBalance=0;
			for(Account acc:accounts1)	{
				if(acc.getAccountNumber()==fromAccNumber)
					currentBalance=currentBalanceDetails.get(acc);
			}
			
			//validating transfer amount: if>current balance, display error
			if(fundAmount<=currentBalance)	{
				transaction.setTransactionDate(LocalDate.now());
				transaction.setDescription(fundDescription);
				transaction.setAmount(fundAmount);
				transaction.setToAccount(toAccNumber);
				transaction.setFromAccount(fromAccNumber);
				transaction.setTransactionType("Fund Transfer");
				
				tr=transactionService.createTransaction(transaction);
			}
			else	{
				out.println("<!DOCTYPE html>\r\n" + 
						"<html>\r\n" + 
						"<head>\r\n" + 
						"<meta charset=\"ISO-8859-1\">\r\n" + 
						"<title>SHBBanking</title>\r\n" + 
						"</head>\r\n" + 
						"<body>\r\nFund Transfer Amount greater than available balance!! Try again!</body></html>");
				tr=null;
			}
			
			
			if(tr!=null) {
				
				out.println("<!DOCTYPE html>\r\n" + 
						"<html>\r\n" + 
						"<head>\r\n" + 
						"<meta charset=\"ISO-8859-1\">\r\n" + 
						"<title>SHBBanking</title>\r\n" + 
						"</head>\r\n" + 
						"<body>\r\nFund Transfer successfully performed!</body></html>");
				System.out.println("Fund Transfer performed!");
			}
			else
				System.out.println("Fund Transfer Failed!");
	
	}
	
}
