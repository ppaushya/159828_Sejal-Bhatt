package org.capg.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.capg.model.Account;
import org.capg.model.Transaction;

public interface ITransactionDao {

	public Transaction createTransaction(Transaction transaction);
	public List<Transaction> getTransactionsForCustomer(int customerId, LocalDate fromDate, LocalDate toDate);
	public Map<Account, Double> getCurrentBalance(int customerId);
		
}
