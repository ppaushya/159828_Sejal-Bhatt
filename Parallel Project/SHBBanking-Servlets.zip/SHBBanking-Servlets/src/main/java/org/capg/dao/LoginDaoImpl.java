package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//this table interacts with customer table of DB
public class LoginDaoImpl implements ILoginDao{

	IAccountDao accountDao=new AccountDao();
	
	//validate login details and return customer object foe the same
	@Override
	public Customer isValidLogin(LoginBean loginBean) {
		
		String sql="select * from customer where email_id=? and customer_pwd=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getUserPassword());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next()) {
				Customer customer=new Customer();
				customer.setCustomerId(rs.getInt(1));
				customer.setFirstName(rs.getString(4));
				customer.setLastName(rs.getString(6));
				return customer;
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	//DB connection
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}


	//Sign Up(create new customer in DB)
	@Override
	public boolean createCustomer(Customer customer) {
		int customerId=0;
		boolean flag=false;
	String sql="insert into customer(customer_id, first_name,last_name,date_of_birth, email_id,mobile_no,customer_pwd, registration_fees)"+
						" values(?,?,?,?,?,?,?,?)";
		
	//add details of customer in Customer table
	try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
		pst.setInt(1, customer.getCustomerId());
		pst.setString(2, customer.getFirstName());
		pst.setString(3, customer.getLastName());
		pst.setDate(4, Date.valueOf(customer.getDateOfBirth()));
		pst.setString(5, customer.getEmailId());
		pst.setString(6,customer.getMobile());
		pst.setString(7,customer.getCustomerPwd());
		pst.setDouble(8, 2500);
		int count=pst.executeUpdate();
		if(count>0)
			flag=true;
		
		if(flag) {
					customerId=customer.getCustomerId();
				
				//add address details of customer in Address table
				String sqlAdd="insert into address(address_line1,address_line2,city,state,pin_code,customer_id) values(?,?,?,?,?,?)";
				
				try(PreparedStatement pst2=getMysqlDbConnection().prepareStatement(sqlAdd)) {
					pst2.setString(1, customer.getAddress().getAddressLine1());
					pst2.setString(2, customer.getAddress().getAddressLine2());
					pst2.setString(3, customer.getAddress().getCity());
					pst2.setString(4, customer.getAddress().getState());
					pst2.setString(5, customer.getAddress().getPincode());
					pst2.setInt(6, customerId);
					
					int count1=pst2.executeUpdate();
					if(count1>0)
						flag=true;
					else
						flag=false;
					
				}
				
			
			} else {
			flag=false;
		}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}
	

}
