package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Transaction;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;
import org.capg.service.ILoginService;
import org.capg.service.ITransactionService;
import org.capg.service.LoginServiceImpl;
import org.capg.service.TransactionServiceImpl;

//This servlet inserts transaction details in DB
@WebServlet("/TransactionServlet")
public class TransactionServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		ITransactionService transactionService=new TransactionServiceImpl();
		
		//Getting details entered in form for performing transaction
		String accounts=request.getParameter("accounts");
		String[] accNo=accounts.split(" -");
		long accNumber=Long.parseLong(accNo[0]);
		String choice=request.getParameter("depositWithdraw");
		String description=request.getParameter("description");
		double amount=Double.parseDouble(request.getParameter("amount"));
		
		PrintWriter out=response.getWriter();
		Transaction tr=new Transaction();
		Transaction transaction=new Transaction();

		HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
		
		//if deposit, perform transaction
			transaction.setTransactionDate(LocalDate.now());
			transaction.setDescription(description);
			transaction.setAmount(amount);
			if(choice.toUpperCase().equals("DEPOSIT"))
			{
				transaction.setTransactionType("Credit");
				transaction.setToAccount(accNumber);
				transaction.setFromAccount(0);
				tr=transactionService.createTransaction(transaction);
			}
		//if withdraw, check if account balance is more than withdrawal amount
			//if not, display error
			else if(choice.toUpperCase().equals("WITHDRAW"))
			{
				//current balance calculation
				Map<Account,Double> currentBalanceDetails=transactionService.getCurrentBalance(custId);
				Set<Account> accounts1=currentBalanceDetails.keySet();
				double currentBalance=0;
				for(Account acc:accounts1)	{
					if(acc.getAccountNumber()==accNumber)
						currentBalance=currentBalanceDetails.get(acc);
				}
				
				transaction.setTransactionType("Debit");
				transaction.setFromAccount(accNumber);
				transaction.setToAccount(0);
				if(amount>currentBalance)
				{
					out.println("<!DOCTYPE html>\r\n" + 
							"<html>\r\n" + 
							"<head>\r\n" + 
							"<meta charset=\"ISO-8859-1\">\r\n" + 
							"<title>SHBBanking</title>\r\n" + 
							"</head>\r\n" + 
							"<body>\r\nWithdrawal Amount greater than available balance!! Try again!</body></html>");
					tr=null;
				}
				else
					//if amount<current balance, perform transaction
					tr=transactionService.createTransaction(transaction);
				
			}
			
			
			if(tr!=null) {
				
				out.println("<!DOCTYPE html>\r\n" + 
						"<html>\r\n" + 
						"<head>\r\n" + 
						"<meta charset=\"ISO-8859-1\">\r\n" + 
						"<title>SHBBanking</title>\r\n" + 
						"</head>\r\n" + 
						"<body>\r\nTransaction successfully performed!</body></html>");
				System.out.println("Transaction performed.....");
			}
			else
				System.out.println("Transaction Failed.....");
		
		
	}
}
