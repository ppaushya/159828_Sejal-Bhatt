package org.capg.service;

import java.util.List;

import org.capg.model.Account;

public interface IAccountService {

	public Account createAccount(Account account);
	public List<Account> getAccountsForCustomer(int customerId);
	public List<Account> getAccountsExceptCustomer(int customerId);

}
