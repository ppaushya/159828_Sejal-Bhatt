package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.capg.model.Account;
import org.capg.model.Transaction;

//this table interacts with transactions table of DB
public class TransactionDaoImpl implements ITransactionDao	{
	

	IAccountDao accountDao=new AccountDao();
	
	//add new transaction to DB
	@Override
	public Transaction createTransaction(Transaction transaction) {
		
		String sql="insert into transactions(transaction_date, transaction_type, amount, from_account, to_account,description,transaction_id) values(?,?,?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			Random r=new Random(); 
			pst.setDate(1, java.sql.Date.valueOf(transaction.getTransactionDate()));
			pst.setString(2, transaction.getTransactionType());
			pst.setDouble(3, transaction.getAmount());
			pst.setLong(4, transaction.getFromAccount());
			pst.setLong(5, transaction.getToAccount());
			pst.setString(6, transaction.getDescription());
			pst.setInt(7, r.nextInt());
			int count=pst.executeUpdate();
			if(count>0)
				return transaction;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	//retrieve all transactions for given customer
	@Override
	public List<Transaction> getTransactionsForCustomer(int customerId, LocalDate fromDate, LocalDate toDate)	{
		
		List<Account> accounts=new ArrayList<>();
		accounts=accountDao.getAccountsForCustomer(customerId);
		List<Transaction> transactions=new ArrayList<>();
		
		for(Account account:accounts)	{
			
			String sql="select * from transactions where from_account="+account.getAccountNumber()+
					" or to_account="+account.getAccountNumber()+";";
			try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
				
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()) {
					Transaction transaction=new Transaction();
					
					transaction.setTransactionId(rs.getInt(1));
					transaction.setTransactionDate(rs.getDate(6).toLocalDate());
					transaction.setTransactionType(rs.getString(7));
					transaction.setAmount(rs.getDouble(2));
					transaction.setFromAccount(rs.getLong(4));
					transaction.setToAccount(rs.getLong(5));
					transaction.setDescription(rs.getString(3));
					
					if((transaction.getTransactionDate().isAfter(fromDate) && transaction.getTransactionDate().isBefore(toDate)) || (toDate.equals(LocalDate.now())))
						transactions.add(transaction);
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return transactions;
	}
	
	//get current balance for all accounts of given customer
	@Override
	public Map<Account, Double> getCurrentBalance(int customerId)	{
		
		List<Account> accounts=new ArrayList<>();
		accounts=accountDao.getAccountsForCustomer(customerId);
		List<Transaction> transactions=new ArrayList<>();
		Map<Account, Double> currentBalance=new HashMap<>();
		
		for(Account account:accounts)	{
			
			double openingBal=account.getOpeningBalance();
			double currentBal=openingBal;
			//System.out.println(currentBal);
			String sql="select * from transactions where from_account="+account.getAccountNumber()+
					" or to_account="+account.getAccountNumber()+";";
			try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
				
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()) {
					Transaction transaction=new Transaction();
					
					transaction.setTransactionId(rs.getInt(1));
					transaction.setTransactionDate(rs.getDate(6).toLocalDate());
					transaction.setTransactionType(rs.getString(7));
					transaction.setAmount(rs.getDouble(2));
					transaction.setFromAccount(rs.getLong(4));
					transaction.setToAccount(rs.getLong(5));
					transaction.setDescription(rs.getString(3));
					
					transactions.add(transaction);
					
					double amt =transaction.getAmount();
					//Calculating current balance
					if(transaction.getFromAccount()==account.getAccountNumber())
						currentBal-=amt;
					else if(transaction.getToAccount()==account.getAccountNumber())
						currentBal+=amt;
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			currentBalance.put(account, currentBal);
		}
		
		return currentBalance;
		
	}
	
	//DB connection
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}

}
