package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

//this servlet implements creating account functionality
@WebServlet("/CreateAccountServlet")
public class CreateAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		ILoginService loginService=new LoginServiceImpl();
		IAccountService accountService=new AccountServiceImpl();
		
		//get user entered data from HTML form
		String accountType=request.getParameter("accountType");
		String balance=request.getParameter("balance");
		String description=request.getParameter("description");
		
		
		//form an account object using entered data
		Account account=new Account();
		account.setAccountType(AccountType.valueOf(accountType));
		account.setDescription(description);
		account.setOpeningBalance(Double.parseDouble(balance));
		account.setOpeningDate(LocalDate.now());
		
		
		HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer=new Customer();
		customer.setCustomerId(custId);
		account.setCustomer(customer);
		
		//create account in DB
		Account acc=accountService.createAccount(account);
		
		
		if(acc!=null) {
			PrintWriter out=response.getWriter();
			out.println("<!DOCTYPE html>\r\n" + 
					"<html>\r\n" + 
					"<head>\r\n" + 
					"<meta charset=\"ISO-8859-1\">\r\n" + 
					"<title>SHBBanking</title>\r\n" + 
					"</head>\r\n" + 
					"<body>\r\nAccount successfully Created!</body></html>");
			System.out.println("Account Inserted!");
		}
		else
			System.out.println("Account Insertion Failed!");
		
		
	}

}
