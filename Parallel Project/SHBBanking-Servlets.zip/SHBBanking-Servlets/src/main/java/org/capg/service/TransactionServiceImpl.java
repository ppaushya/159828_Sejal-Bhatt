package org.capg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.capg.dao.ITransactionDao;
import org.capg.dao.TransactionDaoImpl;
import org.capg.model.Account;
import org.capg.model.Transaction;

public class TransactionServiceImpl implements ITransactionService	{

	private ITransactionDao transactionDao=new TransactionDaoImpl();
	

	@Override
	public Transaction createTransaction(Transaction transaction)	{
		return transactionDao.createTransaction(transaction);
	}
	
	@Override
	public List<Transaction> getTransactionsForCustomer(int customerId, LocalDate fromDate, LocalDate toDate)	{
		return transactionDao.getTransactionsForCustomer(customerId, fromDate, toDate);
	}
	
	@Override
	public Map<Account, Double> getCurrentBalance(int customerId)	{
		return transactionDao.getCurrentBalance(customerId);
	}
	
}
