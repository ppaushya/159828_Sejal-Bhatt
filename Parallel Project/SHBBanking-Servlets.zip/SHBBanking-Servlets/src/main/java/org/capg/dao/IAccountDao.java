package org.capg.dao;

import java.util.List;

import org.capg.model.Account;

public interface IAccountDao {

	public Account createAccount(Account account);
	public List<Account> getAccountsForCustomer(int customerId);
	public List<Account> getAccountsExceptCustomer(int customerId);
}
