package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.capg.model.Account;
import org.capg.model.AccountType;

//this class interacts with accounts table of DB
public class AccountDao implements IAccountDao	{

	//create new account for customer
	@Override
	public Account createAccount(Account account) {
		
		String sql="insert into accounts(customer_id, account_type, opening_date, opening_balance,description, account_no) values(?,?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			Random r=new Random();
			pst.setString(2, account.getAccountType().toString());
			pst.setDate(3,Date.valueOf(account.getOpeningDate()));
			pst.setDouble(4, account.getOpeningBalance());
			pst.setString(5, account.getDescription());
			pst.setInt(1, account.getCustomer().getCustomerId());
			pst.setInt(6, r.nextInt());
			int count=pst.executeUpdate();
			if(count>0)
				return account;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return null;
	}
	
	
	//get all accounts for one customer
	@Override
	public List<Account> getAccountsForCustomer(int customerId)	{
		List<Account> accounts=new ArrayList<>(); 
		
		
		String sql="select * from accounts where customer_id="+customerId+";";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				Account account=new Account();
				account.setAccountNumber(rs.getLong(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				account.setOpeningBalance(rs.getDouble(4));
				accounts.add(account);
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return accounts;
	}
	
	//get all accounts except those of mentioned customer
	@Override
	public List<Account> getAccountsExceptCustomer(int customerId)	{
		List<Account> accounts=new ArrayList<>(); 
		
		
		String sql="select * from accounts where customer_id<>"+customerId+";";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				Account account=new Account();
				account.setAccountNumber(rs.getLong(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				accounts.add(account);
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return accounts;
	}
	
	//DB connection
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}
	
}
