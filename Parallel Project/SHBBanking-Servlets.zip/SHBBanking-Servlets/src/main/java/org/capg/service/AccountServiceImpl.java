package org.capg.service;

import java.util.List;

import org.capg.dao.AccountDao;
import org.capg.dao.IAccountDao;
import org.capg.model.Account;

public class AccountServiceImpl implements IAccountService {
	
	private IAccountDao accountDao=new AccountDao();
	
	@Override
	public Account createAccount(Account account) {
		
		return accountDao.createAccount(account);
	}
	
	@Override
	public List<Account> getAccountsForCustomer(int customerId)	{
		
		return accountDao.getAccountsForCustomer(customerId);
	}
	
	@Override
	public List<Account> getAccountsExceptCustomer(int customerId)	{
		
		return accountDao.getAccountsExceptCustomer(customerId);
	}


}
