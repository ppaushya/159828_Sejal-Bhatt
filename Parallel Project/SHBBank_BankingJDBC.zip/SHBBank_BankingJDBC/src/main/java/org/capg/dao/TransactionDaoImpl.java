package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Transaction;

//class for dealing with transaction details from DB
public class TransactionDaoImpl implements ITransactionDao {

		Map<Account, List<Transaction>> transactions=new HashMap<Account, List<Transaction>>();
		
	//get all transactions performed using an account
	@Override
	public List<Transaction> getAllTransactions(Account account) {
		
		List<Transaction> transactions=new ArrayList<>();
		String str="select * from transactions where from_account="+account.getAccountNo()+" or to_Account="+account.getAccountNo()+";";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				Transaction transaction=new Transaction();
				
					transaction.setTransactionId(resultSet.getInt(1));
					transaction.setTransactionDate(resultSet.getDate(6).toLocalDate());
					transaction.setTransactionType(resultSet.getString(7));
					transaction.setAmount(resultSet.getDouble(2));
					if(resultSet.getLong(4)!=0)
						transaction.setFromAccount(account);
					else
						transaction.setFromAccount(null);
					if(resultSet.getLong(5)!=0)
						transaction.setToAccount(account);
					else
						transaction.setToAccount(null);
					transaction.setDescription(resultSet.getString(3));
		
					transactions.add(transaction);
			
				
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return transactions;
	}
	
	//perform a transaction using an account(add in DB)
	@Override
	public void createTransaction(Account account, Transaction transaction) {
		
		String sql="insert into transactions values(?,?,?,?,?,?,?);";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setLong(1, transaction.getTransactionId());
			statement.setDouble(2, transaction.getAmount());
			statement.setString(7, transaction.getTransactionType());
			statement.setDate(6, java.sql.Date.valueOf(transaction.getTransactionDate()));
			if(transaction.getFromAccount()!=null)
				statement.setLong(4, transaction.getFromAccount().getAccountNo());
			else
				statement.setLong(4, 0);
			if(transaction.getToAccount()!=null)
				statement.setLong(5, transaction.getToAccount().getAccountNo());
			else
				statement.setLong(5, 0);
			statement.setString(3, transaction.getDescription());
			
		
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" row inserted successfully in Transactions table!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//get DB connection
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}

	

}
