package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Address;
import org.capg.model.Customer;

//class for dealing with customer details from DB
public class CustomerDBDaoImpl implements ICustomerDao {

	//get all customer details from DB
	@Override
	public List<Customer> getAllCustomers() {
		
		List<Customer> lst=new ArrayList<>();
		String str="select * from customer;";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				Customer customer=new Customer();
				Address address=new Address();
				Set<Account> accounts=new HashSet<>();
				Account account=new Account();
				AccountType accType=AccountType.SAVINGS;
				
				//get address details for each customer
				String strAddress="select * from address where customer_id="+resultSet.getInt(1)+";";

				PreparedStatement statement1=connection.prepareStatement(strAddress);
				ResultSet resultSet1= statement1.executeQuery();
				
				while(resultSet1.next())
				{
					address.setAddressLine1(resultSet1.getString(1));
					address.setAddressLine2(resultSet1.getString(2));
					address.setCity(resultSet1.getString(3));
					address.setState(resultSet1.getString(5));
					address.setPinCode(resultSet1.getLong(4));
				}
				
				//get account details for each customer
				String strAccount="select * from accounts where customer_id="+resultSet.getInt(1)+";";
				PreparedStatement statement2=connection.prepareStatement(strAccount);
				ResultSet resultSet2= statement2.executeQuery();
				
				while(resultSet2.next())
				{
					account.setAccountNo(resultSet2.getLong(1));
					account.setAccountType(accType.valueOf(resultSet2.getString(2).toUpperCase()));
					account.setOpeningDate(resultSet2.getDate(5).toLocalDate());
					account.setOpeningBalance(resultSet2.getDouble(4));
					account.setDescription(resultSet2.getString(3));
					accounts.add(account);
				}
				
				customer.setCustomerId(resultSet.getInt(1));
				customer.setFirstName(resultSet.getString(4));
				customer.setLastName(resultSet.getString(6));
				customer.setEmailId(resultSet.getString(3));
				customer.setMobile(resultSet.getString(7));
				customer.setDateOfBirth(resultSet.getDate(2).toLocalDate());
				customer.setAddress(address);
				customer.setAccounts(accounts);
				lst.add(customer);
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
		
	}

	//create new customer in DB
	@Override
	public void createCustomer(Customer customer) {
		
		String sql="insert into customer values(?,?,?,?,?,?,?,?,?);";
		String sqlAddr="insert into address values(?,?,?,?,?,?);";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1, customer.getCustomerId());
			statement.setString(4, customer.getFirstName());
			statement.setString(6, customer.getLastName());
			statement.setString(3, customer.getEmailId());
			statement.setString(7, customer.getMobile());
			statement.setDate(2, java.sql.Date.valueOf(customer.getDateOfBirth()));
			statement.setDouble(9, 2500);
			statement.setString(5, "");
			statement.setString(8, customer.getFirstName().toLowerCase()+"123");
			
			//add address details in address table of DB
			Address address=customer.getAddress();
			PreparedStatement statement1=connection.prepareStatement(sqlAddr);
			statement1.setInt(6, customer.getCustomerId());
			statement1.setString(1, address.getAddressLine1());
			statement1.setString(2, address.getAddressLine2());
			statement1.setString(3, address.getCity());
			statement1.setString(5, address.getState());
			statement1.setLong(4, address.getPinCode());
			
			
			int row=statement.executeUpdate();
			int rowAddr=statement1.executeUpdate();
			if(row>0)
				System.out.println(row+" row inserted successfully in customer table!");
			if(rowAddr>0)
				System.out.println(row+" row inserted successfully in address table!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//get DB connection
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


}
