package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Account;
import org.springframework.stereotype.Repository;

@Repository("accountDao")
@Transactional
public class AccountDaoImpl implements IAccountDao	{

	@PersistenceContext
	private EntityManager em;
	
	
	@Override
	public boolean createAccount(Account account) {
		em.persist(account);
		
		return true;
	}

	//get all accounts for one customer
		@Override
		public List<Account> getAccountsForCustomer(int customerId)	{
			List<Account> accs=em.createQuery("from Account acc where acc.customer.customer_id="+customerId).getResultList();
					if(accs!=null)
						return accs;
					else
						return null;
		}
		
		//get all accounts except those of mentioned customer
		@Override
		public List<Account> getAccountsExceptCustomer(int customerId)	{
			
			List<Account> accounts= 
					em.createQuery("from Account acc where acc.customer.customer_id<>"+customerId).getResultList();
			if(accounts!=null)
				return accounts;
			else
				return null;
		}

		@Override
		public Account getAccount(long accountNo) {
			List<Account> accounts=em.createQuery("from Account acc where acc.accountNumber="+accountNo).getResultList();
			Account account=accounts.get(0);
			return account;
		}

}
