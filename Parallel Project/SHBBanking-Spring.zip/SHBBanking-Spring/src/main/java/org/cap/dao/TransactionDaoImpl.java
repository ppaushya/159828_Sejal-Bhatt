package org.cap.dao;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


//this table interacts with transactions table of DB
@Repository("transactionDao")
@Transactional
public class TransactionDaoImpl implements ITransactionDao	{
	

	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	private IAccountDao accountDao;
	
	//add new transaction to DB
	@Override
	public boolean createTransaction(Transaction transaction) {
		
		em.persist(transaction);
		return true;
	}
	
	//retrieve all transactions for given customer
	@Override
	public List<Transaction> getTransactionsForCustomer(int customerId, LocalDate fromDate, LocalDate toDate)	{
		
		List<Account> accounts=new ArrayList<>();
		accounts=accountDao.getAccountsForCustomer(customerId);
		List<Transaction> transactions=new ArrayList<>();
		
		for(Account account:accounts)	{
			
			List<Transaction> tr=em.createQuery("from Transaction where from_account="+account.getAccountNumber()+
					" or to_account="+account.getAccountNumber()).getResultList();
			for(Transaction t:tr)	{
				if((t.getTransaction_date().isAfter(fromDate) && t.getTransaction_date().isBefore(toDate)) || (toDate.equals(LocalDate.now())))
					transactions.add(t);
			}
		}
		
		return transactions;
	}
	
	//get current balance for all accounts of given customer
	@Override
	public Map<Account, Double> getCurrentBalance(int customerId)	{
		
		List<Account> accounts=new ArrayList<>();
		accounts=accountDao.getAccountsForCustomer(customerId);
		List<Transaction> transactions=new ArrayList<>();
		Map<Account, Double> currentBalanceData=new HashMap<>();
		
		for(Account account:accounts)	{
			
			double openingBal=account.getOpening_balance();
			double currentBal=openingBal;
			
			transactions=em.createQuery("from Transaction where from_account="+account.getAccountNumber()+
					" or to_account="+account.getAccountNumber()).getResultList();
			for(Transaction transaction:transactions)	{
					
					double amt =transaction.getAmount();
					//Calculating current balance
					if(transaction.getFrom_account()==account.getAccountNumber())
						currentBal-=amt;
					else if(transaction.getTo_account()==account.getAccountNumber())
						currentBal+=amt;
					
				}
	
			currentBalanceData.put(account, currentBal);
		}
		
		return currentBalanceData;
		
	}


}
