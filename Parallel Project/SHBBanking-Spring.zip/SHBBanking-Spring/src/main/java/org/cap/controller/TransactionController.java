package org.cap.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.cap.service.ITransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TransactionController {

	@Autowired
	private ITransactionService transactionService;
	
	@PostMapping("/depositWithdrawAmt")
	public String depositWithdrawAmt(@Valid @ModelAttribute("depositWithdrawal") Transaction transaction,
			BindingResult result, HttpSession session)  {
		//int customerId=Integer.parseInt(session.getAttribute("custId").toString());
		if(result.hasErrors())
			return "depositWithdraw";
		
		if(transaction.getTransaction_type().toUpperCase().equals("CREDIT"))
		{
			transaction.setTo_account(transaction.getFrom_account());
			transaction.setFrom_account(0);
		}
		//else if(transactionService.checkSufficientAccountBalance(transaction.getFrom_account(), transaction.getAmount(), customerId))	{
			if(transactionService.createTransaction(transaction))
				{
					return "transactionPerformed";
				}
		//}
		/*else
			return "transactionFailure";
*/		return "redirect:/";
	}
	
	@PostMapping("/fundTransfer")
	public String performFundTransfer(@Valid @ModelAttribute("fundTransfer") Transaction transaction,
			BindingResult result, HttpSession session)  {
		//int customerId=Integer.parseInt(session.getAttribute("custId").toString());
		if(result.hasErrors())
			return "fundTransfer";
		//if(transactionService.checkSufficientAccountBalance(transaction.getFrom_account(), transaction.getAmount(), customerId))	{
			if(transactionService.createTransaction(transaction))
				{
					return "transactionPerformed";
				}
			return "redirect:/";
		//}
		/*else
			return "transactionFailure";*/
	}
	
	@PostMapping("/transactionSummary")
	public String getTransactionSummary(@RequestParam("fromDate") String fromDateString,
			@RequestParam("toDate") String toDateString, HttpSession session, ModelMap map)	{
		System.out.println(fromDateString);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate fromDate=LocalDate.parse(fromDateString, formatter);
		LocalDate toDate=LocalDate.parse(toDateString, formatter);
		
		int customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		List<Transaction> transactions=
				transactionService.getTransactionsForCustomer(customerId, fromDate, toDate);
		
		System.out.println(transactions);
		
		map.addAttribute("customerTransactions", transactions);
		
		Map<Account, Double> currentBalanceDetails=
				transactionService.getCurrentBalance(customerId);
		
		map.addAttribute("currentBalDetails", currentBalanceDetails);
		
		return "transactionSummaryResult";
	}
	
}
