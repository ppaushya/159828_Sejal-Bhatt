package org.cap.controller;

import javax.servlet.http.HttpSession;

import org.cap.model.RegisterBean;
import org.cap.service.IRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	@Autowired
	private IRegisterService registerService;
	
	@RequestMapping("/")
	public ModelAndView getIndexPage()	{
		return new ModelAndView("index","login", new RegisterBean());
	}

	@RequestMapping("/validateLogin")
	public String validateLogin(@ModelAttribute("login") RegisterBean registerBean,
			HttpSession session) {
		RegisterBean loginData= registerService.isValidLogin(registerBean);
		if(loginData!=null) 	{
			session.setAttribute("custId", loginData.getCustomer_id());
			session.setAttribute("custName", loginData.getFirst_name());
			session.setAttribute("customer", loginData);

			return "mainpage";
		}
		else
			return "redirect:/";
	}

}
