package org.cap.controller;


import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.cap.model.Account;
import org.cap.model.RegisterBean;
import org.cap.service.IAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AccountController {

	@Autowired
	private IAccountService accountService;
	
	@PostMapping("/createAccount")
	public String createNewAccount(@Valid @ModelAttribute("accountCreation") Account account,
			HttpSession session, BindingResult result)  {
		
		RegisterBean customer=(RegisterBean) session.getAttribute("customer");
		//List<Account> accounts=customer.getAccounts();
		//accounts.add(account);
		//customer.setAccounts(accounts);
		
		account.setCustomer(customer);
		//System.out.println(account);
		
		if(result.hasErrors())
			return "createAccount";
		if(accountService.createAccount(account))
			{
				return "accountCreated";
			}
		return "redirect:/";
	}
	
	
}
