package org.cap.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.cap.service.IAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainPageController {

	@Autowired
	private IAccountService accountService;
	
	@RequestMapping("/titlePage")
	public String displayIFrameContent() {
		return "titlePage";
	}
	
	@RequestMapping("/createAccountPage")
	public String createAccountPage(ModelMap map) {
		
		map.addAttribute("accountCreation", new Account());
		return "createAccount";
	}
	
	@RequestMapping("/depositWithdrawalPage")
	public String depositWithdrawalPage(ModelMap map, HttpSession session) {
		
		int customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		map.addAttribute("depositWithdrawal", new Transaction());
		//System.out.println("here");
		//System.out.println(customerId);
		
		List<Account> accounts=new ArrayList<>();
		accounts=accountService.getAccountsForCustomer(customerId);
		
		Map<Long, String> accountList=new HashMap<>();
		
		for(Account account:accounts)	{
			accountList.put(account.getAccountNumber(), account.getAccountNumber()+" - "+account.getAccount_type());
		}
	
		System.out.println(accountList);
		map.addAttribute("accountList", accountList);
		return "depositWithdraw";
	}
	
	@RequestMapping("/fundTransferPage")
	public String fundTransferPage(ModelMap map, HttpSession session) {

		int customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		map.addAttribute("fundTransfer", new Transaction());
		
		List<Account> fromAccounts=new ArrayList<>();
		fromAccounts=accountService.getAccountsForCustomer(customerId);
		
		Map<Long, String> fromAccountList=new HashMap<>();
		
		for(Account account:fromAccounts)	{
			fromAccountList.put(account.getAccountNumber(), account.getAccountNumber()+" - "+account.getAccount_type());
		}
	
		map.addAttribute("fromAccountList", fromAccountList);
		
		List<Account> toAccounts=new ArrayList<>();
		toAccounts=accountService.getAccountsExceptCustomer(customerId);
		
		Map<Long, String> toAccountList=new HashMap<>();
		
		for(Account account:toAccounts)	{
			toAccountList.put(account.getAccountNumber(), account.getAccountNumber()+" - "+account.getAccount_type());
		}
	
		map.addAttribute("toAccountList", toAccountList);
		
		return "fundTransfer";
	}
	
	@RequestMapping("/transactionSummaryPage")
	public String transactionSummaryPage() {
		
		return "transactionSummary";
	}
	
}
