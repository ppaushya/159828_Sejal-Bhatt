package org.cap.model;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@SequenceGenerator(name="seq", initialValue=20000, allocationSize=100)
@Entity
@Table(name="transactions")
public class Transaction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	private long transaction_id;
	
	private LocalDate transaction_date=LocalDate.now();
	private String transaction_type;
	@NotNull(message="*Please Enter Amount!")
	private double amount;
	private long from_account;
	private long to_account;
	private String description;
	public long getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(long transaction_id) {
		this.transaction_id = transaction_id;
	}
	public LocalDate getTransaction_date() {
		return transaction_date;
	}
	public void setTransaction_date(LocalDate transaction_date) {
		this.transaction_date = transaction_date;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public long getFrom_account() {
		return from_account;
	}
	public void setFrom_account(long from_account) {
		this.from_account = from_account;
	}
	public long getTo_account() {
		return to_account;
	}
	public void setTo_account(long to_account) {
		this.to_account = to_account;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Transaction [transaction_id=" + transaction_id + ", transaction_date=" + transaction_date
				+ ", transaction_type=" + transaction_type + ", amount=" + amount + ", from_account=" + from_account
				+ ", to_account=" + to_account + ", description=" + description + "]";
	}
	public Transaction(long transaction_id, LocalDate transaction_date, String transaction_type, double amount,
			long from_account, long to_account, String description) {
		super();
		this.transaction_id = transaction_id;
		this.transaction_date = transaction_date;
		this.transaction_type = transaction_type;
		this.amount = amount;
		this.from_account = from_account;
		this.to_account = to_account;
		this.description = description;
	}
	
	
	public Transaction()	{}
	

}
