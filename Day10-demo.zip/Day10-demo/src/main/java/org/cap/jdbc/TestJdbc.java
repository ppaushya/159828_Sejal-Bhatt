package org.cap.jdbc;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class TestJdbc {


	public static void main(String[] args)
	{
		
		//load driver class
		try(Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123"))	{
			Class.forName("com.mysql.jdbc.Driver");

			//Connection establishment
			//URL: dbmsname://ip address or hostname:portname/dbname
			

			String sql="create table accounts(customerID int, accountNo bigint,"
					+ "accountType varchar(20), openingDate date, openingBalance double, description varchar(50),"
					+"foreign key fk_customer_acc(customerID) references customer(customerID));";

			Statement statement=connection.createStatement();

			boolean flag=statement.execute(sql);

			if(!flag)
				System.out.println("Table created successfully!");
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		/*finally	{
			try	{
				connection.close();
			}	catch(SQLException e)	{
				e.printStackTrace();
			}
		}*/

	}

}
