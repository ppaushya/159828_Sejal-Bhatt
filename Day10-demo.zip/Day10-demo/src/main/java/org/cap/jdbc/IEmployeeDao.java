package org.cap.jdbc;

import java.util.List;

public interface IEmployeeDao {
	
	public void createEmployee(Employee employee);
	public void deleteEmployee(int employeeID);
	public List<Employee> getAllEmployees();
	public void updateEmployee(int empID, String columnName);
	public Employee findEmployee(int empID);

}
