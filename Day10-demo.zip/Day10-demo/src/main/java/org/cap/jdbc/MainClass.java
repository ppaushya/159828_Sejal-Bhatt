package org.cap.jdbc;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;


public class MainClass {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDaoImpl empDao=new EmployeeDaoImpl();
		int option;
		
		UserInteraction ui=new UserInteraction();
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1. Create Employee");
		System.out.println("2. Update Employee");
		System.out.println("3. Delete Employee");
		System.out.println("4. List all Employees");
		System.out.println("5. Find Employee");
		System.out.println("6. Call Procedure");
		System.out.println("7. Bulk Operation");
		System.out.println("8. Exit");
		option=sc.nextInt();
		
		switch(option)
		{
		case 1:
			Employee emp=ui.createEmployee();
			empDao.createEmployee(emp);
			break;
		case 2:
			empDao.updateEmployee(ui.promptEmployeeIDUpdate(), ui.columnForUpdation());
			break;
		case 3:
			empDao.deleteEmployee(ui.promptEmployeeID());
			break;
		case 4:
			List<Employee> lst=empDao.getAllEmployees();
			ui.printAllEmployees(lst);
			break;
		case 5:
			Employee employee=empDao.findEmployee(ui.promptEmployeeIDFind());
			System.out.println(employee.getEmpID()+"\t"+employee.getFirstName()+"\t"+employee.getLastName()
			+"\t"+employee.getSalary()+"\t"+employee.getDoj());
			break;
		case 7:
			
		case 8:
			System.exit(0);
			break;
		}
		
	}

}
