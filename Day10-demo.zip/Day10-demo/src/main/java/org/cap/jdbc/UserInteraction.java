package org.cap.jdbc;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class UserInteraction {
	
	Scanner sc=new Scanner(System.in);
	
	
	public int promptEmployeeID()
	{
		System.out.println("Enter employee ID to be deleted:");
		return sc.nextInt();
	}
	
	public int promptEmployeeIDUpdate()
	{
		System.out.println("Enter employee ID to be updated:");
		return sc.nextInt();
	}
	
	public int promptEmployeeIDFind()
	{
		System.out.println("Enter employee ID to be found:");
		return sc.nextInt();
	}
	
	
	public String columnForUpdation()
	{
		System.out.println("Enter the column name to be updated:");
		return sc.next();
	}
	
	
	public Employee createEmployee()	{
		Employee employee=new Employee();
		
		System.out.println("Enter employee ID:");
		employee.setEmpID(sc.nextInt());
		
		System.out.println("Enter employee first name:");
		employee.setFirstName(sc.next());
		
		System.out.println("Enter employee last name:");
		employee.setLastName(sc.next());
		
		System.out.println("Enter employee salary:");
		employee.setSalary(sc.nextDouble());
		
		System.out.println("Enter employee date of joining(yyyy-mm-dd):");
		String[] date=sc.next().split("-");
		employee.setDoj(LocalDate.of(Integer.parseInt(date[0]), Integer.parseInt(date[1]),Integer.parseInt(date[2])));
		return employee;
		
	}
	
	
	public void printAllEmployees(List<Employee> lst)	{
		System.out.println("EmpID\tFirstName\tLastName\tSalary\t\tDateOfJoining");
		
		for(Employee element:lst)
		{
			System.out.println(element.getEmpID()+"\t"+
					element.getFirstName()+"\t\t"+
					element.getLastName()+"\t\t"+
					element.getSalary()+"\t\t"+
					element.getDoj());
		}
	}

}
