package org.cap.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EmployeeDaoImpl implements IEmployeeDao {
	
	Scanner sc=new Scanner(System.in);

	public void createEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
		String sql="insert into employee1 values(?,?,?,?,?);";
		
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1, employee.getEmpID());
			statement.setString(2, employee.getFirstName());
			statement.setString(3, employee.getLastName());
			statement.setDouble(4, employee.getSalary());
			statement.setDate(5, java.sql.Date.valueOf(employee.getDoj()));
			
			int row=statement.executeUpdate();

			if(row>0)
				System.out.println(row+" row inserted successfully!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	public void deleteEmployee(int employeeID) {
		// TODO Auto-generated method stub
		String str="delete from employee1 where empid=?";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setInt(1, employeeID);
			
			int row=statement.executeUpdate();

			if(row>0)
				System.out.println(row+" row deleted successfully!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		List<Employee> lst=new ArrayList<>();
		String str="select * from employee1;";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			while(resultSet.next())
			{
				Employee employee=new Employee();
				employee.setEmpID(resultSet.getInt(1));
				employee.setFirstName(resultSet.getString(2));
				employee.setLastName(resultSet.getString(3));
				employee.setSalary(resultSet.getDouble(4));
				employee.setDoj(resultSet.getDate(5).toLocalDate());
				lst.add(employee);
				
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
	}

	@Override
	public void updateEmployee(int empID, String columnName)	{
		List<Employee> lst=new ArrayList<>();
		ResultSet resultSet=null; 
		String str="select * from employee1;";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			resultSet= statement.executeQuery();
			
			while(resultSet.next())
			{
				Employee employee=new Employee();
				employee.setEmpID(resultSet.getInt(1));
				employee.setFirstName(resultSet.getString(2));
				employee.setLastName(resultSet.getString(3));
				employee.setSalary(resultSet.getDouble(4));
				employee.setDoj(resultSet.getDate(5).toLocalDate());
				lst.add(employee);
				
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(resultSet!=null)	{
			String str2=null;
			if(columnName.toUpperCase().equals("FIRSTNAME")||columnName.toUpperCase().equals("LASTNAME")||columnName.toUpperCase().equals("DATEOFJOINING"))
			{
				System.out.println("Enter updated value for "+columnName);
				String name=sc.next();
				str2="update employee1 set "+columnName+" = "+"'"+name+"' where empId="+empID+";";
			}
			else if(columnName.toUpperCase().equals("SALARY"))
			{
				System.out.println("Enter updated value for "+columnName);
				double salary=sc.nextDouble();

				str2="update employee1 set "+columnName+" = "+salary+" where empId="+empID+";";
			}
			else
			{
				System.out.println("Enter a valid column name!");
				return;
			}
			try(Connection connection=getConnection())
			{
				
				PreparedStatement statement=connection.prepareStatement(str2);
				
				int row=statement.executeUpdate();

				if(row>0)
					System.out.println(row+" row updated successfully!");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		else
			System.out.println("Enter a valid employee ID!");
	}

	
	public Employee findEmployee(int empID)
	{
		Employee employee=new Employee();
		String str="select * from employee1 where empId="+empID+";";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			while(resultSet.next())	{
				employee.setEmpID(resultSet.getInt(1));
				employee.setFirstName(resultSet.getString(2));
				employee.setLastName(resultSet.getString(3));
				employee.setSalary(resultSet.getDouble(4));
				employee.setDoj(resultSet.getDate(5).toLocalDate());
				return employee;
			}
			
				System.out.println("Enter a valid employee ID!");
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	

	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}

}
