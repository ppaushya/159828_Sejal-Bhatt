import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { BusinessAnalysisComponent } from './business-analysis/business-analysis.component';
import { BusinessAnalysisService } from './business-analysis/business-analysis.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    BusinessAnalysisComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    HttpClientModule
  ],
  providers: [BusinessAnalysisService],
  bootstrap: [AppComponent]
})
export class AppModule { }
