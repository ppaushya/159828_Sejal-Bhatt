package com.thebank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.thebank.model.User;

public class UserDao implements IUserDao{

	private static final String USER_TABLE = "user";
	private static final String COLUMN_CUSTOMER_ID = "customerId";
	private static final String COLUMN_USER_NAME = "userName";
	private static final String COLUMN_LOGIN_PASSWORD = "loginPassword";
	private static final String COLUMN_SECRET_QUESTION = "secretQuestion";
	private static final String COLUMN_SECRET_QUESTION_ANSWER = "secretQuestionAnswer";
	private static final String COLUMN_TRANSACTION_PASSWORD = "transactionPassword";
	private static final String COLUMN_LOCK_STATUS = "lockStatus";
	
	@Override
	public boolean addUser(User user) {
		try(Connection connection = DatabaseConnection.getConnection()) {

			String sql="insert into "+USER_TABLE+"("
					+COLUMN_CUSTOMER_ID+","
					+COLUMN_USER_NAME+","
					+COLUMN_LOGIN_PASSWORD+","
					+COLUMN_SECRET_QUESTION+","
					+COLUMN_SECRET_QUESTION_ANSWER+","
					+COLUMN_TRANSACTION_PASSWORD+","
					+COLUMN_LOCK_STATUS+")"
					+" values(?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setLong(1, user.getCustomerId());
			preparedStatement.setString(2, user.getUserName());
			preparedStatement.setString(3, user.getLoginPassword());
			preparedStatement.setString(4,user.getSecretQuestion());
			preparedStatement.setString(5,user.getSecretQuestionAnswer());
			preparedStatement.setString(6, user.getTransactionPassword());
			preparedStatement.setString(7, String.valueOf(user.getLockStatus()));
			
			int count = preparedStatement.executeUpdate();
			
			if(count>0) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public User getUserFromUserName(String userName) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+USER_TABLE+" where "
					+ COLUMN_USER_NAME +"=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, userName);
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				User user = new User();
				user.setCustomerId(resultSet.getLong(COLUMN_CUSTOMER_ID));
				user.setUserName(userName);
				user.setLoginPassword(resultSet.getString(COLUMN_LOGIN_PASSWORD));
				user.setSecretQuestion(resultSet.getString(COLUMN_SECRET_QUESTION));
				user.setSecretQuestionAnswer(resultSet.getString(COLUMN_SECRET_QUESTION_ANSWER));
				user.setTransactionPassword(resultSet.getString(COLUMN_TRANSACTION_PASSWORD));
				user.setLockStatus(resultSet.getString(COLUMN_LOCK_STATUS).charAt(0));

				return user;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<User> getAllUsers() {
		Set<User> users = new HashSet<>();
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+USER_TABLE;
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				User user = new User();
				user.setCustomerId(resultSet.getLong(COLUMN_CUSTOMER_ID));
				user.setUserName(resultSet.getString(COLUMN_USER_NAME));
				user.setLoginPassword(resultSet.getString(COLUMN_LOGIN_PASSWORD));
				user.setSecretQuestion(resultSet.getString(COLUMN_SECRET_QUESTION));
				user.setSecretQuestionAnswer(resultSet.getString(COLUMN_SECRET_QUESTION_ANSWER));
				user.setTransactionPassword(resultSet.getString(COLUMN_TRANSACTION_PASSWORD));
				user.setLockStatus(resultSet.getString(COLUMN_LOCK_STATUS).charAt(0));

				users.add(user);
			}
			return users;
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public boolean isUsersExists(String username) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+USER_TABLE+" where "
					+ COLUMN_USER_NAME +"=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, username);
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean isValidUsers(User user) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+USER_TABLE+" where "
					+ COLUMN_USER_NAME +"=? and "
					+ COLUMN_LOGIN_PASSWORD + "=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, user.getUserName());
			statement.setString(2, user.getLoginPassword());
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return false;
	}


	@Override
	public boolean changeLoginPassword(User user) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql="update "+USER_TABLE+" set "
					+ COLUMN_LOGIN_PASSWORD +"=? where "
					+ COLUMN_CUSTOMER_ID +"=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, user.getLoginPassword());
			statement.setLong(2, user.getCustomerId());
			
			int count = statement.executeUpdate();
			if(count>0) {
				return true;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean changeTransactionPassword(User user) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql="update "+USER_TABLE+" set "
					+ COLUMN_TRANSACTION_PASSWORD +"=? where "
					+ COLUMN_CUSTOMER_ID +"=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, user.getTransactionPassword());
			statement.setLong(2, user.getCustomerId());
			
			int count = statement.executeUpdate();
			if(count>0) {
				return true;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean changeLockStatus(User user) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql="update "+USER_TABLE+" set "
					+ COLUMN_LOCK_STATUS +"=? where "
					+ COLUMN_CUSTOMER_ID +"=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, String.valueOf(user.getLockStatus()));
			statement.setLong(2, user.getCustomerId());
			
			int count = statement.executeUpdate();
			if(count>0) {
				return true;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return false;
	}
	
}
