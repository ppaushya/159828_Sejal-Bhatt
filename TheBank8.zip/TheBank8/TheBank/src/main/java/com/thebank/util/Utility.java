package com.thebank.util;

public class Utility {

	public static boolean isValidUser(String userId) {
		return false;
	}

}
