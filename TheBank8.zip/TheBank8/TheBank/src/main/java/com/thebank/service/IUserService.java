package com.thebank.service;

import java.util.Set;

import com.thebank.model.User;

public interface IUserService {

	public boolean addUser(User user);
	public User getUserFromUserName(String userName);
	public Set<User> getAllUsers();
	
	public boolean isUsersExists(String username);
	public boolean isValidUsers(User user);
	
	public boolean changeLoginPassword(User user);
	public boolean changeTransactionPassword(User user);
	public boolean changeLockStatus(User user);
}
