package com.thebank.dao;

import java.util.Set;

import com.thebank.model.Customer;

public interface ICustomerDao {

	public boolean addCustomer(Customer customer);
	public Customer getCustomerFromCustomerId(long customerId);
	public Set<Customer> getAllCustomers();
	public boolean changeCustomerAddress(Customer customer);
	public boolean changeCustomerMobileNo(Customer customer);
	
	public long getLastAddedCustomerId();
}
