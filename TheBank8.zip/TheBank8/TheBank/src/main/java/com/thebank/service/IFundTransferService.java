package com.thebank.service;

import java.util.Set;

import com.thebank.model.FundTransfer;

public interface IFundTransferService {

	public boolean addFundTransfer(FundTransfer fundTransfer);
	public FundTransfer getFundTransferFromFundTranferId(long fundTranferId);
	public Set<FundTransfer> getAllFundTransfers();
	public Set<FundTransfer> getAllFundTransfersFromAccountId(long accountId);
}
