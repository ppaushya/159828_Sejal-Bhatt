package com.thebank.view;

import java.util.List;
import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.ServiceTracker;
import com.thebank.model.Transaction;

public class DisplayUI {

	public static void printAccounts(List<Account> accounts) {
		System.out.println("AccountId\tAccount Type\t Account_balance\t Account OpeningDate");
		System.out.println("------------------------------------------------------------------------------------------------------");
		for(Account account:accounts)
		{
			System.out.println(account.getAccountId()+"\t"
					+account.getAccountType()+"\t"
					+account.getAccountBalance()+"\t"
					+account.getOpenDate()); 
		}
		
	}
	
	
	
	public static void printTransactions(Set<Transaction> transactions) {
		System.out.println("TransactionId\t Transaction Type\t Transaction Amount\t TransactionDate");
		System.out.println("------------------------------------------------------------------------------------------------------");
		for(Transaction transaction:transactions)
		{
			System.out.println(transaction.getTransactionId()+"\t"
					+transaction.getTransactionType()+"\t"
					+transaction.getAmount()+"\t"
					+transaction.getTransactionDate()); 
		}
	}
	
	public static void printServiceTrackers(Set<ServiceTracker> serviceTrackers) {
		System.out.println("ServiceId\tDescription\taccountId\tRaise Date\tStatus");
		System.out.println("------------------------------------------------------------------------------------------------------");
		for(ServiceTracker serviceTracker:serviceTrackers)
		{
			System.out.println(serviceTracker.getServiceId()+"\t"
					+serviceTracker.getServiceDescription()+"\t"
					+serviceTracker.getAccountId()+"\t"
					+serviceTracker.getServiceRaisedDate()+"\t"
					+serviceTracker.getServiceStatus()); 
		}
		
	}
	
	public static void printServiceTracker(ServiceTracker serviceTracker) {
		System.out.println("ServiceId\tDescription\taccountId\tRaise Date\tStatus");
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println(serviceTracker.getServiceId()+"\t"
				+serviceTracker.getServiceDescription()+"\t"
				+serviceTracker.getAccountId()+"\t"
				+serviceTracker.getServiceRaisedDate()+"\t"
				+serviceTracker.getServiceStatus()); 
	}
	
}
