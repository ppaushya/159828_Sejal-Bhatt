package com.thebank.service;

import java.util.Set;

import com.thebank.dao.FundTransferDao;
import com.thebank.dao.IFundTransferDao;
import com.thebank.model.FundTransfer;

public class FundTransferService implements IFundTransferService{

	IFundTransferDao fundTransferDao = new FundTransferDao();
	
	@Override
	public boolean addFundTransfer(FundTransfer fundTransfer) {
		if(fundTransfer==null) {
			throw new IllegalArgumentException();
		}
		return fundTransferDao.addFundTransfer(fundTransfer);
	}

	@Override
	public FundTransfer getFundTransferFromFundTranferId(long fundTranferId) {
		if(fundTranferId<10000) {
			throw new IllegalArgumentException();
		}
		return fundTransferDao.getFundTransferFromFundTranferId(fundTranferId);
	}

	@Override
	public Set<FundTransfer> getAllFundTransfers() {
		return fundTransferDao.getAllFundTransfers();
	}

	@Override
	public Set<FundTransfer> getAllFundTransfersFromAccountId(long accountId) {
		return fundTransferDao.getAllFundTransfersFromAccountId(accountId);
	}

}
