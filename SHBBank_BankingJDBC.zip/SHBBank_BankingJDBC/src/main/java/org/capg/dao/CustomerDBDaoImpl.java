package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Address;
import org.capg.model.Customer;

public class CustomerDBDaoImpl implements ICustomerDao {

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		
		List<Customer> lst=new ArrayList<>();
		String str="select * from customer;";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				Customer customer=new Customer();
				Address address=new Address();
				Set<Account> accounts=new HashSet<>();
				Account account=new Account();
				AccountType accType=AccountType.SAVINGS;
				
				String strAddress="select * from address where customerId="+resultSet.getInt(1)+";";

				PreparedStatement statement1=connection.prepareStatement(strAddress);
				ResultSet resultSet1= statement1.executeQuery();
				
				while(resultSet1.next())
				{
					address.setAddressLine1(resultSet1.getString(2));
					address.setAddressLine2(resultSet1.getString(3));
					address.setCity(resultSet1.getString(4));
					address.setState(resultSet1.getString(5));
					address.setPinCode(resultSet1.getLong(6));
				}
				
				String strAccount="select * from accounts where customerID="+resultSet.getInt(1)+";";
				PreparedStatement statement2=connection.prepareStatement(strAccount);
				ResultSet resultSet2= statement2.executeQuery();
				
				while(resultSet2.next())
				{
					account.setAccountNo(resultSet2.getLong(2));
					account.setAccountType(accType.valueOf(resultSet2.getString(3).toUpperCase()));
					account.setOpeningDate(resultSet2.getDate(4).toLocalDate());
					account.setOpeningBalance(resultSet2.getDouble(5));
					account.setDescription(resultSet2.getString(6));
					accounts.add(account);
				}
				
				customer.setCustomerId(resultSet.getInt(1));
				customer.setFirstName(resultSet.getString(2));
				customer.setLastName(resultSet.getString(3));
				customer.setEmailId(resultSet.getString(4));
				customer.setMobile(resultSet.getString(5));
				customer.setDateOfBirth(resultSet.getDate(6).toLocalDate());
				customer.setAddress(address);
				customer.setAccounts(accounts);
				lst.add(customer);
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
		
	}

	@Override
	public void createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
		String sql="insert into customer values(?,?,?,?,?,?);";
		String sqlAddr="insert into address values(?,?,?,?,?,?);";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1, customer.getCustomerId());
			statement.setString(2, customer.getFirstName());
			statement.setString(3, customer.getLastName());
			statement.setString(4, customer.getEmailId());
			statement.setString(5, customer.getMobile());
			statement.setDate(6, java.sql.Date.valueOf(customer.getDateOfBirth()));
			
			
			
			Address address=customer.getAddress();
			PreparedStatement statement1=connection.prepareStatement(sqlAddr);
			statement1.setInt(1, customer.getCustomerId());
			statement1.setString(2, address.getAddressLine1());
			statement1.setString(3, address.getAddressLine2());
			statement1.setString(4, address.getCity());
			statement1.setString(5, address.getState());
			statement1.setLong(6, address.getPinCode());
			
			
			int row=statement.executeUpdate();
			int rowAddr=statement1.executeUpdate();
			if(row>0)
				System.out.println(row+" row inserted successfully in customer table!");
			if(rowAddr>0)
				System.out.println(row+" row inserted successfully in address table!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


}
