

import java.util.ArrayList;
import java.util.Arrays;

public class Customer {
	
	private int customerId;
	private String customerName;
	private Address address;
	private ArrayList<Account> account=new ArrayList();
	private String mobile;
	private String emailId;
	
	public Customer() {
		
	}
	
	public Customer(int customerId, String customerName, Address address, String mobile,
			String emailId) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.address = address;
		
		this.mobile = mobile;
		this.emailId = emailId;
	}
	
	public Customer(int customerId, String customerName, Address address, ArrayList<Account> account, String mobile,
			String emailId) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.address = address;
		this.account = account;
		this.mobile = mobile;
		this.emailId = emailId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public ArrayList<Account> getAccount() {
		return account;
	}
	public void setAccount(ArrayList<Account> account) {
		this.account = account;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", address=" + address
				+ ", account=" + Arrays.toString(account.toArray()) + ", mobile=" + mobile + ", emailId=" + emailId + "]";
	}
	
	

}
