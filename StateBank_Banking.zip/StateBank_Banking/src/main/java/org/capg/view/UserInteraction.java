package org.capg.view;
import org.capg.model.*;
import org.capg.util.Utility;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class UserInteraction {
	
	Scanner sc=new Scanner(System.in);
	Set<Account> accounts=new HashSet<>();
	
	public Customer getCustomerDetails()	{
		Customer customer=new Customer();
		
		customer.setCustomerId(Utility.generateNumber());
		customer.setFirstName(promptFirstName());
		customer.setLastName(promptLastName());
		customer.setAddress(promptAddress());
		customer.setEmailId(promptEmailId());
		customer.setMobile(promptMobile());
		customer.setDateOfBirth(promptDateOfBirth());
		return customer;
		
	}
	
	
	
	//----------------Customer Validations----------------
	
	public String promptFirstName()	{
			String fname;
			System.out.print("Enter first");
			fname= Utility.isValidName();
			return fname;
	}
	
	public String promptLastName()	{
		String lname;
		System.out.print("Enter last");
		lname= Utility.isValidName();
		return lname;
	}
	
	public Address promptAddress()
	{
		String line1,line2,city,state;
		long pin;
		Address addr=new Address();
		System.out.println("Enter address line 1:");
		line1=sc.next();
		addr.setAddressLine1(line1);
		System.out.println("Enter address line 2:");
		line2=sc.next();
		addr.setAddressLine2(line2);
		System.out.println("Enter city:");
		city=sc.next();
		addr.setCity(city);
		System.out.println("Enter state:");
		state=sc.next();
		addr.setState(state);
		boolean flag=false;
		do	{
	
			System.out.println("Enter pincode:");
			pin=sc.nextLong();
			flag=Long.toString(pin).matches("[0-9]{6}");
			if(flag==false)
			{
				System.out.println("Enter valid 6 digit pincode!");
			}
			
		}while(flag==false);
		
		addr.setPinCode(pin);
		return addr;
	}
	
	public String promptEmailId()	{
		String email;
		
		boolean flag=false;
		do	{
	
			System.out.println("Enter email id:");
			email=sc.next();
			flag=email.matches("[a-z0-9.]{3,}@gmail.com");
			if(flag==false)
			{
				System.out.println("Enter valid email!");
			}
			
		}while(flag==false);
		
		return email;
	}
	
	public String promptMobile()	{
		String mobile;
		
		boolean flag=false;
		do	{
	
			System.out.println("Enter mobile number:");
			mobile=sc.next();
			flag=mobile.matches("[0-9]{10}");
			if(flag==false)
			{
				System.out.println("Enter valid 10 digit mobile number!");
			}
			
		}while(flag==false);
		
		return mobile;
	}
	
	public LocalDate promptDateOfBirth()	{
		
		LocalDate date;
		String dob;
		
		boolean flag=false;
		do	{
	
			System.out.println("Enter date of birth in format DD/MM/YYYY:");
			dob=sc.next();
				flag=dob.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}");
			if(flag==false)
			{
				System.out.println("Enter valid date!");
			}
		}while(flag==false);
		
		
		
		date=LocalDate.parse(dob, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		return date;
		
	}
	//------------------------------------------
	

	public void printCustomers(List<Customer> customers)
	{
		System.out.println("CustomerID\tCustomerName\t"
				+ "EmailID\tMobileNo\tDateOfBirth\tAddress");
		System.out.println("-----------------------------------------------------------------");
		
		for(Customer customer:customers)
		{
			System.out.println(customer.getCustomerId()+"\t"+customer.getFirstName()+" "+
		customer.getLastName()+"\t"+customer.getEmailId()+"\t"+customer.getMobile()+"\t"+
					customer.getDateOfBirth()+"\t"+customer.getAddress());
		}
	}
	
	public void printAccounts(Set<Account> accounts)
	{
		System.out.println("AccountNo\tAccountType\t"
				+ "OpeningBalance\tOpeningDate\tDescription");
		System.out.println("-----------------------------------------------------------------");
		
		for(Account account:accounts)
		{
			System.out.println(account.getAccountNo()+"\t\t"+account.getAccountType()+
					"\t\t"+account.getOpeningBalance()+"\t\t"+account.getOpeningDate()+"\t"+
					account.getDescription());
		}
	}
	
	
	public Customer findallcustomers(List<Customer> customers)
	{
		
		System.out.println("Enter the First Name of the customer for whom you want to create account:");
		
		String name;
		
		name=sc.next();
		
		for(Customer cs : customers)
		{
			//System.out.println(cs.getCustomerId()+"  " +cs.getFirstName()+cs.getLastName() +" " + cs.getEmailId()+" " + cs.getMobileNo() + cs.getAddress());
	 
		if(name.compareTo(cs.getFirstName())==0)
		{
			return cs;
		}
		
		}
		
		return null;
	}
	
	public Customer findCustomerAccounts(List<Customer> customers)
	{
		
		System.out.println("Enter the First Name of the customer for whom you want to create account:");
		
		String name;
		
		name=sc.next();
		
		for(Customer cs : customers)
		{
			
		if(name.compareTo(cs.getFirstName())==0)
		{
			return cs;
		}
		
		}
		System.out.println("Invalid customer name!");
		return null;
	}
	
	
	public Account createAccounts(Customer customer)
	{	
		
		System.out.println("Enter the type of the account you want to create:"
				+ "\n(SAVINGS, CURRENT, RD or FD):");
		
		boolean flag=true;
		AccountType type=AccountType.valueOf(sc.next().toUpperCase());
		Account account=new Account();
		       for(Account ac : accounts )
		       {
		       if(ac.getAccountType().compareTo(type)==0)
		       {
		       System.out.println("Account already exists!");
		       flag=false;
		       }
		       }
		       if(flag)
		       {
					account.setAccountNo(Utility.generateNumber());
					account.setAccountType(type);
					
					if(type==AccountType.SAVINGS)
						account.setOpeningBalance(1000);
					else if(type==AccountType.CURRENT)
						account.setOpeningBalance(2000);
					else if(type==AccountType.FD)
						account.setOpeningBalance(5000);
					else if(type==AccountType.CURRENT)
						account.setOpeningBalance(7000);
					account.setOpeningDate(LocalDate.now());
					account.setDescription("The account is created on "+account.getOpeningDate());
					accounts.add(account);
					customer.setAccounts(accounts);
					
		       }
		       return account;
	}
	

}
