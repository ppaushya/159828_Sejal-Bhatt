package org.capg.boot;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.service.AccountServiceImpl;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.IAccountService;
import org.capg.service.ICustomerService;
import org.capg.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		
		UserInteraction userinteraction = new UserInteraction();
		
		ICustomerService customerservices = new CustomerServiceImpl();
		AccountServiceImpl accountServices = new AccountServiceImpl();
		
		int ch,temp;
		
		boolean flag=true;
		
		String name;
		
		int l=0;
		
		while(flag)
		{
			System.out.println("1.Create a customer");
			System.out.println("2.List the customers");
			System.out.println("3.Create account for a customer");
			System.out.println("4.Perform transactions");
			ch=scanner.nextInt();
			
			if(ch==1)
			{
				customerservices.createCustomer(userinteraction.getCustomerDetails());
				
			}
			else if(ch==2)
			{
				List<Customer> customers = customerservices.getAllCustomers();
				userinteraction.printCustomers(customers);
			}
			
			else if(ch==3)
			{

				List<Customer> customers = customerservices.getAllCustomers();
				Customer customer=userinteraction.findallcustomers(customers);
				
				if(customer==null)
				{
					System.out.println("invalid customer name!");
				}
				else
				{
				  accountServices.createAccount(userinteraction.createAccounts(customer));
				  System.out.println(customer.getAccounts());
				}
				
				
			}
			
			else if(ch==4)
			{
				int transactionType;
				
				List<Customer> customers = customerservices.getAllCustomers();
				Customer customer=userinteraction.findCustomerAccounts(customers);
				System.out.println("Accounts of the mentioned customer are:");
				Set<Account> accounts = accountServices.getAccountsForCustomer(customer);
				userinteraction.printAccounts(accounts);
				System.out.println("\n\n");
				System.out.println("Enter number forthe type of transaction:"
						+ "\n1.Deposit\n2.Withdrawal\n3.Fund Transfer");
				transactionType=scanner.nextInt();
				
				if(transactionType==1)
				{
					
				}
				
			}
			
			System.out.println("enter 1 to continue and 2 to exit");
			temp=scanner.nextInt();
			
			if(temp==2)
			{
				flag=false;
			}
		}
		
		
	}

}
