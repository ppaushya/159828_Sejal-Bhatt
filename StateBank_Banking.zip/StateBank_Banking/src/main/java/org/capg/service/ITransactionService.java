package org.capg.service;

import java.util.List;
import java.util.Set;

import org.capg.model.Transaction;

public interface ITransactionService {

public void createTransaction(Transaction transaction);
	
	public List<Transaction> getAllTransactions();
	
}
