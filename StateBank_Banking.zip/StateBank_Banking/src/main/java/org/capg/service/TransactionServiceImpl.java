package org.capg.service;

import java.util.List;

import org.capg.dao.ITransactionDao;
import org.capg.dao.TransactionDaoImpl;
import org.capg.model.Transaction;

public class TransactionServiceImpl implements ITransactionService {

	
	private ITransactionDao transDao=new TransactionDaoImpl();
	
	@Override
	public void createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		transDao.createTransaction(transaction);
	}

	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return transDao.getAllTransactions();
	}

	
	
}
