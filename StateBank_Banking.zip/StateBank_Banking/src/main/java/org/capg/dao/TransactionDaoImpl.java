package org.capg.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.capg.model.Transaction;

public class TransactionDaoImpl implements ITransactionDao {
	
	List<Transaction> transactions = dummyTransactions();
	private static List<Transaction> dummyTransactions()	{
		
		List<Transaction> transactions=new ArrayList<>();
		
		return transactions;
	}
	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return transactions;
	}
	@Override
	public void createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		transactions.add(transaction);
	}
	
	

}
