package org.capg.dao;

import java.util.List;

import org.capg.model.Transaction;

public interface ITransactionDao {

	public List<Transaction> getAllTransactions();
	public void createTransaction(Transaction transaction);
	
}
