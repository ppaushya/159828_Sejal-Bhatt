package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

@WebServlet("/InsertFundTransfer")
public class InsertFundTransfer extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		ILoginService loginService=new LoginServiceImpl();

			String fromAccounts=request.getParameter("fromAccounts");
			String[] fromAccNo=fromAccounts.split(" -");
			long fromAccNumber=Long.parseLong(fromAccNo[0]);
			
			String toAccounts=request.getParameter("toAccounts");
			String[] toAccNo=toAccounts.split(" -");
			long toAccNumber=Long.parseLong(toAccNo[0]);
			
			String fundDescription=request.getParameter("fundDescription");
			double fundAmount=Double.parseDouble(request.getParameter("fundAmount"));
			
			Transaction transaction=new Transaction();
	
	
			transaction.setTransactionDate(LocalDate.now());
			transaction.setDescription(fundDescription);
			transaction.setAmount(fundAmount);
			transaction.setToAccount(toAccNumber);
			transaction.setFromAccount(fromAccNumber);
			transaction.setTransactionType("Fund Transfer");
			
			Transaction tr=loginService.createTransaction(transaction);
			if(tr!=null) {
				PrintWriter out=response.getWriter();
				out.println("<!DOCTYPE html>\r\n" + 
						"<html>\r\n" + 
						"<head>\r\n" + 
						"<meta charset=\"ISO-8859-1\">\r\n" + 
						"<title>SHBBanking</title>\r\n" + 
						"</head>\r\n" + 
						"<body>\r\nFund Transfer successfully performed!</body></html>");
				System.out.println("Fund Transfer performed!");
			}
			else
				System.out.println("Fund Transfer Failed!");
	
	}
	
}
