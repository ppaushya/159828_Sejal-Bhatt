package org.capg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.capg.dao.ILoginDao;
import org.capg.dao.LoginDaoImpl;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

public class LoginServiceImpl implements ILoginService{

	private ILoginDao loginDao=new LoginDaoImpl();
	
	@Override
	public Customer isValidLogin(LoginBean loginBean) {
		/*if(loginBean.getUserName().equals("tom") && 
				loginBean.getUserPassword().equals("tom123")) {
			return true;
		}*/
		
		/*if(loginDao.isValidLogin(loginBean))
			return true;*/
		
		return loginDao.isValidLogin(loginBean);
	}

	@Override
	public boolean createCustomer(Customer customer) {
		
		return loginDao.createCustomer(customer);
	}

	@Override
	public Account createAccount(Account account) {
		
		return loginDao.createAccount(account);
	}
	
	@Override
	public List<Account> getAccountsForCustomer(int customerId)	{
		
		return loginDao.getAccountsForCustomer(customerId);
	}
	
	@Override
	public List<Account> getAccountsExceptCustomer(int customerId)	{
		
		return loginDao.getAccountsExceptCustomer(customerId);
	}
	
	@Override
	public Transaction createTransaction(Transaction transaction)	{
		
		return loginDao.createTransaction(transaction);
	}
	
	@Override
	public List<Transaction> getTransactionsForCustomer(int customerId, LocalDate fromDate, LocalDate toDate)	{
		return loginDao.getTransactionsForCustomer(customerId, fromDate, toDate);
	}
	
	@Override
	public Map<Account, Double> getCurrentBalance(int customerId)	{
		return loginDao.getCurrentBalance(customerId);
	}
	
	public double getOpeningBalance(long accNumber)	{
		return loginDao.getOpeningBalance(accNumber);
	}
}
