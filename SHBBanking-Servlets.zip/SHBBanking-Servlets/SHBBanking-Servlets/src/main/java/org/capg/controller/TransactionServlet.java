package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

@WebServlet("/TransactionServlet")
public class TransactionServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		ILoginService loginService=new LoginServiceImpl();
		
		
		//Deposit Withdrawal operation variables
		String accounts=request.getParameter("accounts");
		String[] accNo=accounts.split(" -");
		long accNumber=Long.parseLong(accNo[0]);
		String choice=request.getParameter("depositWithdraw");
		String description=request.getParameter("description");
		double amount=Double.parseDouble(request.getParameter("amount"));
		double openingBal=0;
	
		PrintWriter out=response.getWriter();
		Transaction tr=new Transaction();
		
		
		Transaction transaction=new Transaction();

			transaction.setTransactionDate(LocalDate.now());
			transaction.setDescription(description);
			transaction.setAmount(amount);
			if(choice.toUpperCase().equals("DEPOSIT"))
			{
				transaction.setTransactionType("Credit");
				transaction.setToAccount(accNumber);
				transaction.setFromAccount(0);
				tr=loginService.createTransaction(transaction);
			}
			else if(choice.toUpperCase().equals("WITHDRAW"))
			{
				openingBal=loginService.getOpeningBalance(accNumber);
				System.out.println(openingBal+ " "+amount);
				transaction.setTransactionType("Debit");
				transaction.setFromAccount(accNumber);
				transaction.setToAccount(0);
				if(amount>openingBal)
				{
					out.println("<!DOCTYPE html>\r\n" + 
							"<html>\r\n" + 
							"<head>\r\n" + 
							"<meta charset=\"ISO-8859-1\">\r\n" + 
							"<title>SHBBanking</title>\r\n" + 
							"</head>\r\n" + 
							"<body>\r\nWithdrawal Amount greater than available balance!!</body></html>");
					tr=null;
				}
				else
					tr=loginService.createTransaction(transaction);
				
			}
			
			
			if(tr!=null) {
				
				out.println("<!DOCTYPE html>\r\n" + 
						"<html>\r\n" + 
						"<head>\r\n" + 
						"<meta charset=\"ISO-8859-1\">\r\n" + 
						"<title>SHBBanking</title>\r\n" + 
						"</head>\r\n" + 
						"<body>\r\nTransaction successfully performed!</body></html>");
				System.out.println("Transaction performed.....");
			}
			else
				System.out.println("Transaction Failed.....");
		
		
	}
}
