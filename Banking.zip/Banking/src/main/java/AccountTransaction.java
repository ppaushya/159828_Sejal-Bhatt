import java.util.Scanner;

public class AccountTransaction {

	
	
	public Account findAccount(long accountNo,Customer customer) {
		
		
		for(Account account:customer.getAccount()) {
			if(account!=null) {
				if(account.getAccountNo()==accountNo) {
					return account;
				}
			}
		}
		
		return null;
	}
	
	
	public boolean isValidAccount(long accountNo,Customer customer) {
		boolean flag=false;
		
		for(Account account:customer.getAccount()) {
			if(account!=null) {
				if(account.getAccountNo()==accountNo) {
					flag=true;
					break;
				}
			}
		}
		
		return flag;
	}
	
	
	
	
	public static long generateAccountNo() {
		Scanner sc=new Scanner(System.in);
		long accNo= (long)(Math.random()*10000)/10;
		if(Long.toString(accNo).matches("\\d{3,6}"))
		{return accNo;}
		else
		{
			System.out.println("Enter valid account number(having 3 to 6 digits):");
			accNo=sc.nextLong();
			return accNo;
		}
	}
	
	public void printAccounts(Customer customer) {
		Account[] accounts=customer.getAccount();
		for(Account account:accounts) {
			if(account!=null)
				System.out.println(account.getAccountNo()+"\t"+account.getAccountType());
			else
				break;
		}
	}
	
}
