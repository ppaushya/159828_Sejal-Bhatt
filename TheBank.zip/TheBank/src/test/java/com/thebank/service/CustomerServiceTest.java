package com.thebank.service;

import org.junit.Before;

import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.thebank.dao.ICustomerDao;

import com.thebank.model.Customer;

public class CustomerServiceTest {

	@Mock
	ICustomerDao customerDao;

	static ICustomerService customerServices;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		customerServices = new CustomerService(customerDao);
	}

	@Test(expected = IllegalArgumentException.class)
	public void test_null_customer_creation() {
		Customer customer = new Customer();

		customer = null;
		customerServices.addCustomer(customer);

	}

	@Test
	public void test_createCustomer_successful() {
		Customer customer = new Customer(101, "Rajesh", "raj@gmail.com", "9876564321", "Ram gali, UP", "GAURA6969S",
				null);

		Mockito.when(customerDao.addCustomer(customer)).thenReturn(true);
		customerServices.addCustomer(customer);

		Mockito.verify(customerDao).addCustomer(customer);

	}

}
