package com.thebank.view;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.AccountType;
import com.thebank.model.Customer;
import com.thebank.model.Payee;
import com.thebank.model.ServiceTracker;
import com.thebank.model.User;
import com.thebank.service.AccountService;
import com.thebank.service.CustomerService;
import com.thebank.service.IAccountService;
import com.thebank.service.ICustomerService;
import com.thebank.service.IUserService;
import com.thebank.service.UserService;
import com.thebank.util.Validator;

public class PromptUI {
	
	static Scanner scanner = new Scanner(System.in);
	static IUserService userService = new UserService();
	static ICustomerService customerService = new CustomerService();
	static IAccountService accountService = new AccountService();
	
	//check the admin password provided
	public static boolean checkAdminPassword() {
		boolean flag=false;
		int count=0;
		System.out.println("Enter Admin Password: ");
		do {
		
			String adminPassword=scanner.next();
			
			if(adminPassword.matches("India123")) {
				return true;
			}
			else {
				if(count==0) {
					System.out.println("Enter Correct Admin Password: ");
				}
				else if(count==1) {
					System.out.println("You have made 2 Incorrect attempts! This is your last attempt");
				}
				else if(count==2) {
					System.out.println("You have made 3 Incorrect Attempts!\nPlease contact IT Department");
					System.exit(0);
				}
				count++;
			}
		} while (flag==false);
		
		return false;
	}
	
	//enter the login credentials for user
	public static User promptLoginCredentialAndGetUser() {
		User user = new User();
		
		boolean success = false, flag=false;
		String userName;
		System.out.println("Enter User Name");
		do {
			userName=scanner.next();
			success = userService.isUsersExists(userName);
			if(!success) {
				System.out.println("Enter Valid User Name:");
			}
		}while(!success);
         
		//retrieve from DB user full credentials
		user = userService.getUserFromUserName(userName);
		if(user.getLockStatus()=='L') {
			System.out.println("Your Account is Locked! Contact Bank Admin");
			return null;
		}
		System.out.println("Do you remember your Password? : [Y/N]");
		do {
			String str=scanner.next();
			if(str.charAt(0)=='Y'||str.charAt(0)=='y') {
				int count=0;
				System.out.println("Enter your Login Password: ");
				do {
					String loginPassword=scanner.next();
					
					user.setLoginPassword(loginPassword);
					success = userService.isValidUsers(user);
					if(!success) {  //to lock our account if 3 attempts have been made
						count++;
						if(count==1) {
							System.out.println("Invalid password\nEnter your Correct Login Password");
						}
						else if(count==2) {
							System.out.println("You have made 2 Incorrect attempts!\nThis is your last attempt");
						}
						else if(count==3) {
							System.out.println("You have made 3 Incorrect attempts. Your account is locked for Security Reasons.\nContact your Bank for Further Updates...");
							user.setLockStatus('L');
							userService.changeLockStatus(user);
						}
					}
				}while(!success);
				flag=true;    //if forgot password then enter security question
			}else if(str.charAt(0)=='N'||str.charAt(0)=='n'){
				System.out.println("Answer the Following Question:");
				System.out.println(userService.getUserFromUserName(userName).getSecretQuestion());
				boolean success1=false;
				int count=0;
				do {
					String answer=scanner.next();
					if(answer.toUpperCase().equals(userService.getUserFromUserName(userName).getSecretQuestionAnswer().toUpperCase())) {
						user.setLoginPassword("sbq500#");  //give dummy login password
						userService.changeLoginPassword(user);
						System.out.println("Your new password is sbq500#");
						success1=true;
					}else {
						count++;
						if(count==1) {
							System.out.println("Enter Correct Response:");
						}else if(count==2) {
							System.out.println("You have made 2 Incorrect attempts! This is your last attempt");
						}else if(count==3) {
							System.out.println("You have made 3 Incorrect attempts. Your account is locked for Security Reasons.\nContact your Bank for Further Updates...");
							user.setLockStatus('L');
							userService.changeLockStatus(user);
							success1=true;
						}
					}
				}while(!success1);
				
				
				return promptLoginCredentialAndGetUser();
			}else {
				System.out.println("Enter a valid choice");
			}
		}while(flag==false);
		return user;
	}
	
	//enter all the customer details 
	public static Customer promptCustomer() {
		Customer customer = new Customer();
		
		String customerName="";
		System.out.println("Enter name: ");
		do{
			customerName = scanner.nextLine();
			if(!Validator.validateCustomerName(customerName)) {
				System.out.println("Enter Valid Name:");
			}
		}while(!Validator.validateCustomerName(customerName));
		customer.setCustomerName(customerName);
		
		String email="";
		boolean success=false;
		do {
			System.out.println("Enter Email Id: ");
			do{
				email = scanner.next();
				if(!Validator.validateEmail(email)) {
					System.out.println("Enter Valid Email Id: ");
				}
			}while(!Validator.validateEmail(email));
			success = !customerService.isEmailExists(email);
			if(!success) {
				System.out.println("Email ID Already Exists!");
			}
		}while(!success);
		customer.setEmail(email);
		
		String mobile="";
		System.out.println("Enter Mobile Number: ");
		do{
			mobile = scanner.next();
			if(!Validator.validateMobileNumber(mobile)) {
				System.out.println("Enter Valid Mobile Number: ");
			}
		}while(!Validator.validateMobileNumber(mobile));
		customer.setMobileNo(mobile);

		System.out.println("Enter address: ");
		String address = scanner.next();
		address = address + scanner.nextLine();
		customer.setAddress(address);
		
		String panCard="";
		boolean success2=false;
		do {
			System.out.println("Enter Pan Card Number: ");
			do{
				panCard = scanner.next();
				if(!Validator.validatePanCard(panCard)) {
					System.out.println("Enter Valid Pan Card Number: ");
				}
			}while(!Validator.validatePanCard(panCard));
			success2 = !customerService.isPanCardExists(panCard);
			if(!success2) {
				System.out.println("Pan Card Already Exists!");
			}
		}while(!success2);
		customer.setPancard(panCard);
		
		return customer;
		
	}
	
	//enter the account details for that customer to open account 
	public static Account promptAccount(Customer customer) {
		Account account = new Account();
		account.setCustomerId(customer.getCustomerId());
		
		System.out.println();
		System.out.println("Enter account details:");
		System.out.println("-------------------------");
		AccountType accountType = promptAccountType();
		account.setAccountType(accountType);
		
		account.setOpenDate(LocalDate.now());
		
		double balance = promptAmount("Enter Opening Balance");
		account.setAccountBalance(balance);
		
		return account;
	}
	
	//enter the user details for sign up 
	public static User promptUser(Customer customer) {
		User user = new User();
		user.setCustomerId(customer.getCustomerId());
		
		String userName="";
		System.out.println("Create a User Name: ");
		do {
			do{
				userName = scanner.next();
				if(!Validator.validateUserName(userName)) {
					System.out.println("Create a Valid User Name: ");
				}
			}while(!Validator.validateUserName(userName));
			if(userService.isUsersExists(userName)) {
				System.out.println("User Name already Exists! Please select a new User Name:");
			}
		}while(userService.isUsersExists(userName));
		user.setUserName(userName);
		
		String loginPassword="";
		System.out.println("Enter login password: ");
		do{
			loginPassword = scanner.next();
			if(!Validator.validatePassword(loginPassword)) {
				System.out.println("Enter Proper Login Password");
			}
		}while(!Validator.validatePassword(loginPassword));
		String confirmLoginPassword="";
		System.out.println("Confirm Login Password: ");
		do{
			confirmLoginPassword = scanner.next();
			if(!loginPassword.equals(confirmLoginPassword)) {
				System.out.println("Password And Confirm Password Must Match!");
			}
		}while(!loginPassword.equals(confirmLoginPassword));
		
		user.setLoginPassword(loginPassword);
		
		user.setSecretQuestion(getSecretQuestion());

		System.out.println("Enter Secret Question Answer: ");
		String secretQuestionAnswer = scanner.next();
		user.setSecretQuestionAnswer(secretQuestionAnswer);
		
		String transactionPassword="";
		System.out.println("Enter transaction password: ");
		do{
			transactionPassword = scanner.next();
			if(!Validator.validatePassword(transactionPassword)) {
				System.out.println("Enter Proper Transaction Password");
			}
		}while(!Validator.validatePassword(transactionPassword));
		String confirmTransactionPassword="";
		System.out.println("Confirm Transaction Password: ");
		do{
			confirmTransactionPassword = scanner.next();
			if(!transactionPassword.equals(confirmTransactionPassword)) {
				System.out.println("Password And Confirm Password Must Match!");
			}
		}while(!transactionPassword.equals(confirmTransactionPassword));
		
		user.setTransactionPassword(transactionPassword);
		user.setLockStatus('U');
		
		return user;
	}
	
	//prompt the payee details to add 
	public static Payee promptPayee(Customer customer) {
		Set<Account> customerAccounts = accountService.getAllAccountsOfCustomer(customer.getCustomerId());
		Account account = PromptUI.getAccountChoice(customerAccounts); //choose the account
		
		
		Payee payee = new Payee();
		payee.setAccountId(account.getAccountId());
		
		System.out.println("Select payee acount:");
		Set<Account> allAccounts = accountService.getAllAccountsExceptGivenCustomer(customer.getCustomerId());
		Account payeeAccount = PromptUI.getAccountChoice(allAccounts);
		if(payeeAccount==null) {
			return null;
		}
		payee.setPayeeAccountId(payeeAccount.getAccountId());
		
		String nickName="";
		do{
			System.out.println("Enter nick name: ");
			nickName = scanner.next();
		}while(!Validator.validateUserName(nickName));
		payee.setNickname(nickName);
		
		return payee;
	}
	
	public static AccountType promptAccountType() {
		AccountType[] accountTypes = AccountType.values();
		int count=0;
		for(AccountType accountType : accountTypes) {
			System.out.println((++count) + ". for "+accountType);
		}

		AccountType accountType=null;
		int accountTypeNo;
		while(accountType==null) {
			System.out.println("Choose Account Type:");
			accountTypeNo = scanner.nextInt();
			accountType = getAccountTypeFromValue(accountTypeNo);
			if(accountType==null) {
				System.out.println("Invalid Account type");
			}
		}
		return accountType;
	}
	
	//different enum values for account Type
	public static AccountType getAccountTypeFromValue(int value) {
		switch (value) {
			case 1:
				return AccountType.SAVINGS;
			case 2:
				return AccountType.CURRENT;
			case 3:
				return AccountType.RD;
			case 4:
				return AccountType.FD;
			default:
				return null;
		}
	}
	
	//get the secret questions 
	public static String getSecretQuestion() {
		
		System.out.println("Select a Secret Question:");
		System.out.println("1. What was your childhood nickname?");
		System.out.println("2. Where were you Born?");
		System.out.println("3. What is your favorite team?");
		System.out.println("4. Who is your childhood sports hero?");
		System.out.println("5. What was name of your First School?");
		System.out.println("Enter your choice[1,2,3,4,5]:");
		
		boolean flag=false;
		
		do {
			int secretQuestion = scanner.nextInt();
			
			switch (secretQuestion) {
			case 1:
				return "What was your childhood nickname?";
			case 2:
				return "Where were you Born?";
			case 3:
				return "What is your favorite team?";
			case 4:
				return "Who is your childhood sports hero?";
			case 5:
				return "What was name of your First School?";
			default:
				System.out.println("Enter Valid Choice");
			}
		}while(flag==false);
		
		return "";
	}
	
	/*private static LocalDate getDateFromUser(String message) {
		String date="";
		while(!Validator.validateDate(date)) {
			System.out.println(message);
			date = scanner.next();
		}
		String dateParts[] = date.split("-");
		return LocalDate.of(Integer.parseInt(dateParts[2]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[0]));
	}*/
	
	//prompt the new mobile number
	public static String promptMobileNumber() {
		String mobile="";
		do{
			System.out.println("Enter mobile number: ");
			mobile = scanner.next();
		}while(!Validator.validateMobileNumber(mobile));
		return mobile;
	}

	//prompt the amount to fund transferred
	public static double promptAmount(String message) {
		double amount=0;
		do{
			System.out.println(message);
			amount = scanner.nextDouble();
			if(amount<=0) {
				System.out.println("Invalid amount");
			}
		}while(amount<=0);
		return amount;
	}
	
	//select the customer from given customers to print 
	public static Customer getCustomerChoice(Set<Customer> customers) {
		if(customers.size()<=0) {
			System.out.println("No customers available");
			return null;
		}
		System.out.println();
		System.out.println("Select customer from following:");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()+" "+customer.getCustomerName());
		}
		
		Customer customer=null;
		while(customer==null) {
			System.out.println("Choose customer id: ");
			long customerId = scanner.nextLong();
			customer = getCustomerFromCustomerId(customers, customerId);
			if(customer==null) {
				System.out.println("Invalid customer id");
			}
		}
		return customer;
	}
	
	private static Customer getCustomerFromCustomerId(Set<Customer> customers,long customerId) {
		for(Customer customer:customers) {
			if(customer.getCustomerId()==customerId) {
				return customer;
			}
		}
		return null;
	}
	
	//of which account you want to do further functionality
	public static Account getAccountChoice(Set<Account> accounts) {
		if(accounts.size()<=0) {
			System.out.println("No accounts available");
			return null;
		}
		System.out.println();
		System.out.println("Select account from following:");
		
		for(Account account:accounts) {
			System.out.println(account.getAccountId()+" "+account.getAccountType());
		}
		
		Account account=null;
		while(account==null) {
			System.out.println("Choose account id: ");
			long accountId = scanner.nextLong();
			account = getAccountFromAccountId(accounts, accountId);
			if(account==null) {
				System.out.println("Invalid account id");
			}
		}
		return account;
	}
	
	//get the account from that account ID
	private static Account getAccountFromAccountId(Set<Account> accounts,long accountId) {
		for(Account account:accounts) {
			if(account.getAccountId()==accountId) {
				return account;
			}
		}
		return null;
	}
	
	//how much services available for that customerId
	public static ServiceTracker getServiceChoice(Set<ServiceTracker> serviceTrackers) {
		if(serviceTrackers.size()<=0) {
			System.out.println("No services available");
			return null;
		}
		System.out.println();
		System.out.println("Select service from following:");
		
		for(ServiceTracker serviceTracker:serviceTrackers) {
			System.out.println(serviceTracker.getServiceId()+" "+serviceTracker.getServiceDescription());
		}
		
		ServiceTracker serviceTracker=null;
		while(serviceTracker==null) {
			System.out.println("Choose service id: ");
			long serviceTrackerId = scanner.nextLong();
			serviceTracker = getServiceFromServiceId(serviceTrackers, serviceTrackerId);
			if(serviceTracker==null) {
				System.out.println("Invalid service id");
			}
		}
		return serviceTracker;
	}
	
	private static ServiceTracker getServiceFromServiceId(Set<ServiceTracker> serviceTrackers,long serviceTrackerId) {
		for(ServiceTracker serviceTracker:serviceTrackers) {
			if(serviceTracker.getServiceId()==serviceTrackerId) {
				return serviceTracker;
			}
		}
		return null;
	}
	
	public static Payee getPayeeChoice(Set<Payee> payees) {
		if(payees.size()<=0) {
			System.out.println("No payees available");
			return null;
		}
		System.out.println();
		System.out.println("Select account from following:");
		
		for(Payee payee:payees) {
			System.out.println(payee.getPayeeAccountId()+" "+payee.getNickname());
		}
		
		Payee payee=null;
		while(payee==null) {
			System.out.println("Choose account id: ");
			long payeeId = scanner.nextLong();
			payee = getPayeeFromPayeeId(payees, payeeId);
			if(payee==null) {
				System.out.println("Invalid account id");
			}
		}
		return payee;
	}
	
	private static Payee getPayeeFromPayeeId(Set<Payee> payees,long accountId) {
		for(Payee payee:payees) {
			if(payee.getPayeeAccountId()==accountId) {
				return payee;
			}
		}
		return null;
	}	
}
