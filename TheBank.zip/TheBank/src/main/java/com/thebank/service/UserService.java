package com.thebank.service;

import java.util.Set;

import com.thebank.dao.IUserDao;
import com.thebank.dao.UserDao;
import com.thebank.model.User;

public class UserService implements IUserService{
	IUserDao userDao = new UserDao();
	
	public UserService() {}
	public UserService(IUserDao userDao) {
		this.userDao=userDao;
	}
	
	@Override
	public boolean addUser(User user) {
		if(user==null)
		{
			throw new IllegalArgumentException();
		}
		return userDao.addUser(user);
	}

	@Override
	public User getUserFromUserName(String userName) {
		return userDao.getUserFromUserName(userName);
	}

	@Override
	public Set<User> getAllUsers() {
		return userDao.getAllUsers();
	}

	@Override
	public boolean isUsersExists(String username) {
		return userDao.isUsersExists(username);
	}

	@Override
	public boolean isValidUsers(User user) {
		return userDao.isValidUsers(user);
	}

	
	@Override
	public boolean changeLoginPassword(User user) {
		return userDao.changeLoginPassword(user);
	}

	@Override
	public boolean changeTransactionPassword(User user) {
		return userDao.changeLockStatus(user);
	}

	@Override
	public boolean changeLockStatus(User user) {
		return userDao.changeLockStatus(user);
	}

}
