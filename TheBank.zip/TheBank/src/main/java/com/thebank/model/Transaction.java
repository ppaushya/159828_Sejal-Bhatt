package com.thebank.model;

import java.time.LocalDate;

public class Transaction {
	private long transactionId;
	private LocalDate transactionDate;
	private double amount;
	private String description;
	private char transactionType;
	private long accountId;

	public Transaction() {
		super();
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public char getTransactionType() {
		return transactionType;
	}
	
	public void setTransactionType(char transactionType) {
		this.transactionType = transactionType;
	}
	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", transactionDate=" + transactionDate + ", amount="
				+ amount + ", description=" + description + ", transactionType=" + transactionType + ", accountId="
				+ accountId + "]";
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public Transaction(LocalDate transactionDate, double amount, String description, char transactionType,
			long accountId) {
		super();
		this.transactionDate = transactionDate;
		this.amount = amount;
		this.description = description;
		this.transactionType = transactionType;
		this.accountId = accountId;
	}
}
