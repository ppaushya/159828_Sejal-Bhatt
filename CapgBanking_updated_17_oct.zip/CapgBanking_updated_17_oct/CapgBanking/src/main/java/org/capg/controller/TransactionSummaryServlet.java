package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

@WebServlet("/TransactionSummaryServlet")
public class TransactionSummaryServlet extends HttpServlet	{
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		
		PrintWriter out=response.getWriter();
		
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>SHBBanking</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<form method=\"post\" action=\"PrintTransactionSummary\">\r\n" + 
				"	<div>\r\n" + 
				"		<table>\r\n" + 
				"			<tr>\r\n" + 
				"				<th colspan=\"3\">Get Transaction Summary</th>\r\n" + 
				"			</tr>\r\n" +
				"			<tr>\r\n" + 
				"				<td>From Date:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"date\" name=\"fromDate\" size=\"20\">  \r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>To Date:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"date\" name=\"toDate\" size=\"20\">  \r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td></td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"submit\" value=\"Get Transaction Summary\" name=\"getSummary\" >\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"		\r\n" + 
				"		</table>\r\n" + 
				"	\r\n" + 
				"	</div>\r\n" + 
				"\r\n" + 
				"</form>\r\n" + 
				"</body>\r\n" + 
				"</html>");
		
	}

}
