package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

@WebServlet("/FundTransferServlet")
public class FundTransferServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		ILoginService loginService=new LoginServiceImpl();
		PrintWriter out=response.getWriter();
		
		
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>SHBBanking</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<form method=\"post\" action=\"InsertFundTransfer\">\r\n" + 
				"	<div>\r\n" + 
				"		<table>\r\n" + 
				"			<tr>\r\n" + 
				"				<th colspan=\"3\">Perform Fund Transfer</th>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>From Account:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<select name=\"fromAccounts\">");
		
		HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
		
		List<Account> customerAccounts=new ArrayList<>();
		customerAccounts=loginService.getAccountsForCustomer(custId);
		
		for(Account account:customerAccounts)	{
			
			out.println("<option value=\""+account.getAccountNumber()+"\">"+
			account.getAccountNumber()+" - "+account.getAccountType().toString()+"</option>");
		}

		out.println("</select>\r\n</td></tr>" +
				"				<tr>\r\n" + 
				"				<td>To Account:</td>\r\n" + 
				"				<td>\r\n" +
				"<select name=\"toAccounts\">");
		
		customerAccounts=loginService.getAccountsExceptCustomer(custId);
		
		for(Account account:customerAccounts)	{
			
			out.println("<option value=\""+account.getAccountNumber()+"\">"+
			account.getAccountNumber()+" - "+account.getAccountType().toString()+"</option>");
		}
				out.println("				</select>\r\n</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Amount:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"text\" name=\"fundAmount\" size=\"20\">  \r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Description:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"text\" name=\"fundDescription\" size=\"20\">  \r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td></td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"submit\" value=\"Perform Fund Transfer\" name=\"fundTransfer\" >\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"		\r\n" + 
				"		</table>\r\n" + 
				"	\r\n" + 
				"	</div>\r\n" + 
				"\r\n" + 
				"</form>\r\n" + 
				"</body>\r\n" + 
				"</html>");
		
		
		
	}

	
}
