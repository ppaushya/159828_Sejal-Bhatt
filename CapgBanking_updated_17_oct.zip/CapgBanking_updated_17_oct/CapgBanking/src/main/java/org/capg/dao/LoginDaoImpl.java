package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoginDaoImpl implements ILoginDao{

	@Override
	public Customer isValidLogin(LoginBean loginBean) {
		
		String sql="select * from customer where emailId=? and customerPwd=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getUserPassword());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next()) {
				Customer customer=new Customer();
				customer.setCustomerId(rs.getInt(1));
				customer.setFirstName(rs.getString(2));
				customer.setLastName(rs.getString(3));
				return customer;
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}


	@Override
	public boolean createCustomer(Customer customer) {
		int customerId=0;
		boolean flag=false;
	String sql="insert into customer(customerId, firstName,lastName,dateOfBirth, emailId,mobileNo,customerPwd)"+
						" values(?,?,?,?,?,?,?)";
		
	try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
		pst.setInt(1, customer.getCustomerId());
		pst.setString(2, customer.getFirstName());
		pst.setString(3, customer.getLastName());
		pst.setDate(4, Date.valueOf(customer.getDateOfBirth()));
		pst.setString(5, customer.getEmailId());
		pst.setString(6,customer.getMobile());
		pst.setString(7,customer.getCustomerPwd());
		
		int count=pst.executeUpdate();
		if(count>0)
			flag=true;
		
		if(flag) {
			String sqlMax="select max(customerId) from customer";
			try(PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sqlMax)) {
				ResultSet rs= pst1.executeQuery();
				if(rs.next())
					customerId=rs.getInt(1);
				
				
				String sqlAdd="insert into address(addressline1,addressline2,city,state,pincode,customerId) values(?,?,?,?,?,?)";
				
				try(PreparedStatement pst2=getMysqlDbConnection().prepareStatement(sqlAdd)) {
					pst2.setString(1, customer.getAddress().getAddressLine1());
					pst2.setString(2, customer.getAddress().getAddressLine2());
					pst2.setString(3, customer.getAddress().getCity());
					pst2.setString(4, customer.getAddress().getState());
					pst2.setString(5, customer.getAddress().getPincode());
					pst2.setInt(6, customerId);
					
					int count1=pst2.executeUpdate();
					if(count1>0)
						flag=true;
					else
						flag=false;
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else {
			flag=false;
		}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}


	@Override
	public Account createAccount(Account account) {
		
		String sql="insert into accounts(customerId, accountType, openingDate, openingBalance,description) values(?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			
			pst.setString(2, account.getAccountType().toString());
			pst.setDate(3,Date.valueOf(account.getOpeningDate()));
			pst.setDouble(4, account.getOpeningBalance());
			pst.setString(5, account.getDescription());
			pst.setInt(1, account.getCustomer().getCustomerId());
			int count=pst.executeUpdate();
			if(count>0)
				return account;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}
	
	
	public List<Account> getAccountsForCustomer(int customerId)	{
		List<Account> accounts=new ArrayList<>(); 
		
		
		String sql="select * from accounts where customerId="+customerId+";";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				Account account=new Account();
				account.setAccountNumber(rs.getLong(2));
				account.setAccountType(AccountType.valueOf(rs.getString(3)));
				account.setOpeningBalance(rs.getDouble(5));
				accounts.add(account);
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return accounts;
	}
	
	public List<Account> getAccountsExceptCustomer(int customerId)	{
		List<Account> accounts=new ArrayList<>(); 
		
		
		String sql="select * from accounts where customerId<>"+customerId+";";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				Account account=new Account();
				account.setAccountNumber(rs.getLong(2));
				account.setAccountType(AccountType.valueOf(rs.getString(3)));
				accounts.add(account);
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return accounts;
	}
	
	
	@Override
	public Transaction createTransaction(Transaction transaction) {
		
		String sql="insert into transactions(transactionDate, transactionType, amount, fromAccount, toAccount,description) values(?,?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			
			pst.setDate(1, java.sql.Date.valueOf(transaction.getTransactionDate()));
			pst.setString(2, transaction.getTransactionType());
			pst.setDouble(3, transaction.getAmount());
			pst.setLong(4, transaction.getFromAccount());
			pst.setLong(5, transaction.getToAccount());
			pst.setString(6, transaction.getDescription());
			int count=pst.executeUpdate();
			if(count>0)
				return transaction;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	@Override
	public List<Transaction> getTransactionsForCustomer(int customerId, LocalDate fromDate, LocalDate toDate)	{
		
		List<Account> accounts=new ArrayList<>();
		accounts=getAccountsForCustomer(customerId);
		List<Transaction> transactions=new ArrayList<>();
		
		for(Account account:accounts)	{
			
			String sql="select * from transactions where fromAccount="+account.getAccountNumber()+
					" or toAccount="+account.getAccountNumber()+";";
			try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
				
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()) {
					Transaction transaction=new Transaction();
					
					transaction.setTransactionId(rs.getInt(1));
					transaction.setTransactionDate(rs.getDate(2).toLocalDate());
					transaction.setTransactionType(rs.getString(3));
					transaction.setAmount(rs.getDouble(4));
					transaction.setFromAccount(rs.getLong(5));
					transaction.setToAccount(rs.getLong(6));
					transaction.setDescription(rs.getString(7));
					
					if(transaction.getTransactionDate().isAfter(fromDate) && transaction.getTransactionDate().isBefore(toDate))
						transactions.add(transaction);
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return transactions;
	}
	
	
	
	public Map<Account, Double> getCurrentBalance(int customerId)	{
		
		List<Account> accounts=new ArrayList<>();
		accounts=getAccountsForCustomer(customerId);
		List<Transaction> transactions=new ArrayList<>();
		Map<Account, Double> currentBalance=new HashMap<>();
		
		for(Account account:accounts)	{
			
			double openingBal=account.getOpeningBalance();
			double currentBal=openingBal;
			//System.out.println(currentBal);
			String sql="select * from transactions where fromAccount="+account.getAccountNumber()+
					" or toAccount="+account.getAccountNumber()+";";
			try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
				
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()) {
					Transaction transaction=new Transaction();
					
					transaction.setTransactionId(rs.getInt(1));
					transaction.setTransactionDate(rs.getDate(2).toLocalDate());
					transaction.setTransactionType(rs.getString(3));
					transaction.setAmount(rs.getDouble(4));
					transaction.setFromAccount(rs.getLong(5));
					transaction.setToAccount(rs.getLong(6));
					transaction.setDescription(rs.getString(7));
					
					transactions.add(transaction);
					
					double amt =transaction.getAmount();
					//Calculating current balance
					if(transaction.getFromAccount()==account.getAccountNumber())
						currentBal-=amt;
					else if(transaction.getToAccount()==account.getAccountNumber())
						currentBal+=amt;
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			currentBalance.put(account, currentBal);
		}
		
		return currentBalance;
		
	}

}
